# WordPress MySQL database migration
#
# Generated: Saturday 16. June 2018 23:17 UTC
# Hostname: localhost
# Database: `wp_inhabitent`
# URL: //localhost/student
# Path: /Applications/MAMP/htdocs/student
# Tables: wp_cfs_sessions, wp_cfs_values, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, adventures, attachment, cfs, customize_changeset, nav_menu_item, page, post, products, wpforms
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_cfs_sessions`
#

DROP TABLE IF EXISTS `wp_cfs_sessions`;


#
# Table structure of table `wp_cfs_sessions`
#

CREATE TABLE `wp_cfs_sessions` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `data` text,
  `expires` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cfs_sessions`
#
INSERT INTO `wp_cfs_sessions` ( `id`, `data`, `expires`) VALUES
('0c02e88295bc01a88d8657a0fb9ad82f', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528961381'),
('579f5da4ba9159e146c5d9644107124b', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528958751'),
('6d8bd1813d29aa95da987bd9e8d6e37e', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528961282'),
('77e3f4cfeb9adf57ac0ef4509d56e20d', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528961257'),
('864808dd7d79531bd6571c7da3a6e83e', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528959392'),
('af918b5e9dcf4b5c8352cd45569eaf4f', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528959359'),
('b76e63f32663221dedf9307f34355827', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528958732'),
('b86864d460639db4c9743bbb8168cb99', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528961114'),
('bcd47f60b47eca6e3e7498b2138cc667', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528961389'),
('beabb9c1b8e706ae37796e19cb48d3ef', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528961288'),
('c1e40f0e99595553dbf2597f5dea73fa', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528959421'),
('e20d4ba67e90b70e5f64c88545579913', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528961266'),
('eea9358d4df7379fe36f82f2596caa10', 'a:7:{s:7:"post_id";i:4;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:122;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1528961331') ;

#
# End of data contents of table `wp_cfs_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_cfs_values`
#

DROP TABLE IF EXISTS `wp_cfs_values`;


#
# Table structure of table `wp_cfs_values`
#

CREATE TABLE `wp_cfs_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(10) unsigned DEFAULT NULL,
  `meta_id` int(10) unsigned DEFAULT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  `base_field_id` int(10) unsigned DEFAULT '0',
  `hierarchy` text,
  `depth` int(10) unsigned DEFAULT '0',
  `weight` int(10) unsigned DEFAULT '0',
  `sub_weight` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `field_id_idx` (`field_id`),
  KEY `post_id_idx` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cfs_values`
#
INSERT INTO `wp_cfs_values` ( `id`, `field_id`, `meta_id`, `post_id`, `base_field_id`, `hierarchy`, `depth`, `weight`, `sub_weight`) VALUES
(79, 1, 392, 81, 0, '', 0, 0, 0),
(80, 2, 393, 81, 0, '', 0, 0, 0),
(81, 1, 394, 80, 0, '', 0, 0, 0),
(82, 2, 395, 80, 0, '', 0, 0, 0),
(83, 1, 396, 79, 0, '', 0, 0, 0),
(84, 2, 397, 79, 0, '', 0, 0, 0),
(85, 1, 398, 78, 0, '', 0, 0, 0),
(86, 2, 399, 78, 0, '', 0, 0, 0),
(87, 1, 400, 77, 0, '', 0, 0, 0),
(88, 2, 401, 77, 0, '', 0, 0, 0),
(89, 1, 402, 76, 0, '', 0, 0, 0),
(90, 2, 403, 76, 0, '', 0, 0, 0),
(91, 1, 404, 75, 0, '', 0, 0, 0),
(92, 2, 405, 75, 0, '', 0, 0, 0),
(93, 1, 406, 74, 0, '', 0, 0, 0),
(94, 2, 407, 74, 0, '', 0, 0, 0),
(95, 1, 408, 73, 0, '', 0, 0, 0),
(96, 2, 409, 73, 0, '', 0, 0, 0),
(97, 1, 410, 72, 0, '', 0, 0, 0),
(98, 2, 411, 72, 0, '', 0, 0, 0),
(99, 1, 412, 71, 0, '', 0, 0, 0),
(100, 2, 413, 71, 0, '', 0, 0, 0),
(101, 1, 414, 70, 0, '', 0, 0, 0),
(102, 2, 415, 70, 0, '', 0, 0, 0),
(103, 1, 416, 51, 0, '', 0, 0, 0),
(104, 2, 417, 51, 0, '', 0, 0, 0),
(105, 1, 418, 69, 0, '', 0, 0, 0),
(106, 2, 419, 69, 0, '', 0, 0, 0),
(107, 1, 420, 50, 0, '', 0, 0, 0),
(108, 2, 421, 50, 0, '', 0, 0, 0),
(109, 1, 422, 49, 0, '', 0, 0, 0),
(110, 2, 423, 49, 0, '', 0, 0, 0),
(115, 3, 454, 4, 0, '', 0, 0, 0) ;

#
# End of data contents of table `wp_cfs_values`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=750 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/student', 'yes'),
(2, 'home', 'http://localhost/student', 'yes'),
(3, 'blogname', 'Inhabitent', 'yes'),
(4, 'blogdescription', 'Inhabitent Camping Supply Co', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'mail@server.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:155:{s:11:"products/?$";s:28:"index.php?post_type=products";s:41:"products/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=products&feed=$matches[1]";s:36:"products/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=products&feed=$matches[1]";s:28:"products/page/([0-9]{1,})/?$";s:46:"index.php?post_type=products&paged=$matches[1]";s:13:"adventures/?$";s:30:"index.php?post_type=adventures";s:43:"adventures/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?post_type=adventures&feed=$matches[1]";s:38:"adventures/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?post_type=adventures&feed=$matches[1]";s:30:"adventures/page/([0-9]{1,})/?$";s:48:"index.php?post_type=adventures&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:36:"products/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"products/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"products/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"products/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"products/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"products/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"products/([^/]+)/embed/?$";s:41:"index.php?products=$matches[1]&embed=true";s:29:"products/([^/]+)/trackback/?$";s:35:"index.php?products=$matches[1]&tb=1";s:49:"products/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?products=$matches[1]&feed=$matches[2]";s:44:"products/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?products=$matches[1]&feed=$matches[2]";s:37:"products/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?products=$matches[1]&paged=$matches[2]";s:44:"products/([^/]+)/comment-page-([0-9]{1,})/?$";s:48:"index.php?products=$matches[1]&cpage=$matches[2]";s:33:"products/([^/]+)(?:/([0-9]+))?/?$";s:47:"index.php?products=$matches[1]&page=$matches[2]";s:25:"products/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"products/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"products/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"products/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"products/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"products/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:38:"adventures/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:48:"adventures/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:68:"adventures/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"adventures/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"adventures/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"adventures/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:27:"adventures/([^/]+)/embed/?$";s:43:"index.php?adventures=$matches[1]&embed=true";s:31:"adventures/([^/]+)/trackback/?$";s:37:"index.php?adventures=$matches[1]&tb=1";s:51:"adventures/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?adventures=$matches[1]&feed=$matches[2]";s:46:"adventures/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?adventures=$matches[1]&feed=$matches[2]";s:39:"adventures/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?adventures=$matches[1]&paged=$matches[2]";s:46:"adventures/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?adventures=$matches[1]&cpage=$matches[2]";s:35:"adventures/([^/]+)(?:/([0-9]+))?/?$";s:49:"index.php?adventures=$matches[1]&page=$matches[2]";s:27:"adventures/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"adventures/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"adventures/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"adventures/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"adventures/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"adventures/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"product_type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?product_type=$matches[1]&feed=$matches[2]";s:48:"product_type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?product_type=$matches[1]&feed=$matches[2]";s:29:"product_type/([^/]+)/embed/?$";s:45:"index.php?product_type=$matches[1]&embed=true";s:41:"product_type/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?product_type=$matches[1]&paged=$matches[2]";s:23:"product_type/([^/]+)/?$";s:34:"index.php?product_type=$matches[1]";s:31:"cfs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"cfs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"cfs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"cfs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:20:"cfs/([^/]+)/embed/?$";s:51:"index.php?post_type=cfs&name=$matches[1]&embed=true";s:24:"cfs/([^/]+)/trackback/?$";s:45:"index.php?post_type=cfs&name=$matches[1]&tb=1";s:32:"cfs/([^/]+)/page/?([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&paged=$matches[2]";s:39:"cfs/([^/]+)/comment-page-([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&cpage=$matches[2]";s:28:"cfs/([^/]+)(?:/([0-9]+))?/?$";s:57:"index.php?post_type=cfs&name=$matches[1]&page=$matches[2]";s:20:"cfs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:"cfs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:"cfs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"cfs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=55&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:16:{i:0;s:31:"query-monitor/query-monitor.php";i:1;s:19:"akismet/akismet.php";i:2;s:47:"business-hours-widget/business-hours-widget.php";i:3;s:26:"custom-field-suite/cfs.php";i:4;s:74:"debug-bar-actions-and-filters-addon/debug-bar-action-and-filters-addon.php";i:5;s:41:"debug-bar-rewrite-rules/rewrite-rules.php";i:6;s:49:"debug-bar-slow-actions/debug-bar-slow-actions.php";i:7;s:23:"debug-bar/debug-bar.php";i:8;s:9:"hello.php";i:9;s:53:"inhabitent-functionality/inhabitent-functionality.php";i:10;s:31:"kint-debugger/kint-debugger.php";i:11;s:49:"log-deprecated-notices/log-deprecated-notices.php";i:12;s:27:"theme-check/theme-check.php";i:13;s:31:"wp-log-viewer/wp-log-viewer.php";i:14;s:31:"wp-migrate-db/wp-migrate-db.php";i:15;s:24:"wpforms-lite/wpforms.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'inhabitent', 'yes'),
(41, 'stylesheet', 'inhabitent', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:2:{s:41:"debug-bar-rewrite-rules/rewrite-rules.php";s:17:"umdbrr_deactivate";s:49:"log-deprecated-notices/log-deprecated-notices.php";a:2:{i:0;s:14:"Deprecated_Log";i:1;s:12:"on_uninstall";}}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '56', 'yes'),
(84, 'page_on_front', '55', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '32', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:8:"Archives";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:13:"custom_html-2";i:1;s:27:"inhabitent-business-hours-2";i:2;s:10:"archives-2";}s:14:"footer-sidebar";a:1:{i:0;s:27:"inhabitent-business-hours-3";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:2:{i:2;a:2:{s:5:"title";s:12:"Contact Info";s:7:"content";s:622:"<div class="site-contact">\r\n	<ul class="fa-ul">\r\n		\r\n		<li>\r\n			<span class="fa-li"><i class="fas fa-phone"></i></span><a class="phone" href="tel:+17784567891" rel="nofollow">+1 778-456-7891</a>\r\n		</li>\r\n		\r\n		<li>\r\n			<span class="fa-li"><i class="fas fa-envelope"></i></span><a class="email" href="mailto:info@inhabitent.com" rel="nofollow">info@inhabitent.com</a>\r\n		</li>\r\n\r\n		<li>\r\n			<span class="fa-li"><i class="fas fa-map-marker-alt"></i></span>\r\n			<a class="map" href="https://goo.gl/maps/iWd1p2u7NA82" rel="nofollow" target="_blank">1490 W Broadway <br />Vancouver, BC V6H 1H5</a>\r\n		</li>\r\n		\r\n	</ul>\r\n</div>";}s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'cron', 'a:5:{i:1529191335;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1529203963;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1529205467;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1529205487;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(110, 'theme_mods_twentyseventeen', 'a:3:{s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:3:"top";i:14;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1526954845;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(125, 'can_compress_scripts', '0', 'no'),
(136, 'current_theme', 'RED Starter Theme', 'yes'),
(137, 'theme_mods_inhabitent', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:14;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(138, 'theme_switched', '', 'yes'),
(166, 'recently_activated', 'a:0:{}', 'yes'),
(179, 'debug_bar_rewrite_rules_filters_list', 'a:3:{s:4:"list";a:15:{i:0;s:22:"category_rewrite_rules";i:1;s:25:"post_format_rewrite_rules";i:2;s:22:"products_rewrite_rules";i:3;s:24:"adventures_rewrite_rules";i:4;s:26:"product_type_rewrite_rules";i:5;s:17:"cfs_rewrite_rules";i:6;s:18:"post_rewrite_rules";i:7;s:18:"date_rewrite_rules";i:8;s:18:"root_rewrite_rules";i:9;s:22:"comments_rewrite_rules";i:10;s:20:"search_rewrite_rules";i:11;s:20:"author_rewrite_rules";i:12;s:18:"page_rewrite_rules";i:13;s:17:"tag_rewrite_rules";i:14;s:19:"rewrite_rules_array";}s:5:"count";i:14;s:7:"details";a:14:{s:22:"category_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:25:"post_format_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:22:"products_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:24:"adventures_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:26:"product_type_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:17:"cfs_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:18:"post_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:18:"date_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:18:"root_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:22:"comments_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:20:"search_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:20:"author_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:18:"page_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:17:"tag_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}}}', 'yes'),
(180, 'debug_bar_rewrite_rules_installed', '1', 'yes'),
(181, 'widget_akismet_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(188, 'log_deprecated_notices', 'a:2:{s:11:"last_viewed";s:19:"2018-04-27 01:57:16";s:10:"db_version";i:4;}', 'yes'),
(197, 'category_children', 'a:0:{}', 'yes'),
(235, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(297, 'cfs_next_field_id', '4', 'yes'),
(298, 'cfs_version', '2.5.12', 'yes'),
(403, 'theme_switch_menu_locations', 'a:1:{s:3:"top";i:14;}', 'yes'),
(404, 'theme_switched_via_customizer', '', 'yes'),
(405, 'customize_stashed_theme_mods', 'a:0:{}', 'no'),
(449, 'product_type_children', 'a:0:{}', 'yes'),
(499, 'wpforms_preview_page', '118', 'yes'),
(500, 'wpforms_version', '1.4.6', 'yes'),
(501, 'wpforms_activated', 'a:1:{s:4:"lite";i:1527118292;}', 'yes'),
(504, 'widget_wpforms-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(505, '_amn_wpforms-lite_last_checked', '1529107200', 'yes'),
(506, 'wpforms_review', 'a:2:{s:4:"time";i:1528580312;s:9:"dismissed";b:1;}', 'yes'),
(532, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1529191048;}', 'no'),
(695, 'widget_inhabitent-business-hours', 'a:3:{i:2;a:4:{s:5:"title";s:14:"Business Hours";s:8:"weekdays";s:10:"9am to 5pm";s:8:"saturday";s:11:"10am to 2am";s:6:"sunday";s:6:"Closed";}i:3;a:4:{s:5:"title";s:14:"Business Hours";s:8:"weekdays";s:10:"9am to 5pm";s:8:"saturday";s:10:"9am to 5pm";s:6:"sunday";s:6:"Closed";}s:12:"_multiwidget";i:1;}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=455 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1528947176:1'),
(4, 6, '_edit_last', '1'),
(5, 6, '_edit_lock', '1527118329:1'),
(6, 8, '_edit_last', '1'),
(7, 8, '_edit_lock', '1524797879:1'),
(8, 11, '_edit_last', '1'),
(9, 11, '_edit_lock', '1529033353:1'),
(10, 13, '_edit_last', '1'),
(11, 13, '_edit_lock', '1527045076:1'),
(12, 15, '_edit_last', '1'),
(13, 15, '_edit_lock', '1527045098:1'),
(14, 17, '_edit_last', '1'),
(15, 17, '_edit_lock', '1527045115:1'),
(16, 19, '_edit_last', '1'),
(17, 19, '_edit_lock', '1527045139:1'),
(19, 22, '_menu_item_type', 'custom'),
(20, 22, '_menu_item_menu_item_parent', '0'),
(21, 22, '_menu_item_object_id', '22'),
(22, 22, '_menu_item_object', 'custom'),
(23, 22, '_menu_item_target', ''),
(24, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(25, 22, '_menu_item_xfn', ''),
(26, 22, '_menu_item_url', 'http://localhost/student/'),
(27, 22, '_menu_item_orphaned', '1524942861'),
(28, 23, '_menu_item_type', 'post_type'),
(29, 23, '_menu_item_menu_item_parent', '0'),
(30, 23, '_menu_item_object_id', '4'),
(31, 23, '_menu_item_object', 'page'),
(32, 23, '_menu_item_target', ''),
(33, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(34, 23, '_menu_item_xfn', ''),
(35, 23, '_menu_item_url', ''),
(36, 23, '_menu_item_orphaned', '1524942861'),
(37, 24, '_menu_item_type', 'post_type'),
(38, 24, '_menu_item_menu_item_parent', '0'),
(39, 24, '_menu_item_object_id', '6'),
(40, 24, '_menu_item_object', 'page'),
(41, 24, '_menu_item_target', ''),
(42, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(43, 24, '_menu_item_xfn', ''),
(44, 24, '_menu_item_url', ''),
(45, 24, '_menu_item_orphaned', '1524942861'),
(55, 26, '_menu_item_type', 'custom'),
(56, 26, '_menu_item_menu_item_parent', '0'),
(57, 26, '_menu_item_object_id', '26'),
(58, 26, '_menu_item_object', 'custom'),
(59, 26, '_menu_item_target', ''),
(60, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(61, 26, '_menu_item_xfn', ''),
(62, 26, '_menu_item_url', 'http://localhost/student/'),
(63, 26, '_menu_item_orphaned', '1524942882'),
(64, 27, '_menu_item_type', 'post_type'),
(65, 27, '_menu_item_menu_item_parent', '0'),
(66, 27, '_menu_item_object_id', '4'),
(67, 27, '_menu_item_object', 'page'),
(68, 27, '_menu_item_target', ''),
(69, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(70, 27, '_menu_item_xfn', ''),
(71, 27, '_menu_item_url', ''),
(72, 27, '_menu_item_orphaned', '1524942882'),
(73, 28, '_menu_item_type', 'post_type'),
(74, 28, '_menu_item_menu_item_parent', '0'),
(75, 28, '_menu_item_object_id', '6'),
(76, 28, '_menu_item_object', 'page'),
(77, 28, '_menu_item_target', ''),
(78, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(79, 28, '_menu_item_xfn', ''),
(80, 28, '_menu_item_url', ''),
(81, 28, '_menu_item_orphaned', '1524942882'),
(92, 31, '_wp_attached_file', '2018/04/inhabitent-logo-full-512x512.png'),
(93, 31, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:40:"2018/04/inhabitent-logo-full-512x512.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:40:"inhabitent-logo-full-512x512-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:40:"inhabitent-logo-full-512x512-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(94, 32, '_wp_attached_file', '2018/04/cropped-inhabitent-logo-full-512x512.png'),
(95, 32, '_wp_attachment_context', 'site-icon'),
(96, 32, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:48:"2018/04/cropped-inhabitent-logo-full-512x512.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:48:"cropped-inhabitent-logo-full-512x512-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:48:"cropped-inhabitent-logo-full-512x512-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-270";a:4:{s:4:"file";s:48:"cropped-inhabitent-logo-full-512x512-270x270.png";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-192";a:4:{s:4:"file";s:48:"cropped-inhabitent-logo-full-512x512-192x192.png";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-180";a:4:{s:4:"file";s:48:"cropped-inhabitent-logo-full-512x512-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";}s:12:"site_icon-32";a:4:{s:4:"file";s:46:"cropped-inhabitent-logo-full-512x512-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(108, 34, '_menu_item_type', 'post_type'),
(109, 34, '_menu_item_menu_item_parent', '0'),
(110, 34, '_menu_item_object_id', '4'),
(111, 34, '_menu_item_object', 'page'),
(112, 34, '_menu_item_target', ''),
(113, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(114, 34, '_menu_item_xfn', ''),
(115, 34, '_menu_item_url', ''),
(117, 35, '_menu_item_type', 'post_type'),
(118, 35, '_menu_item_menu_item_parent', '0'),
(119, 35, '_menu_item_object_id', '6'),
(120, 35, '_menu_item_object', 'page'),
(121, 35, '_menu_item_target', ''),
(122, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(123, 35, '_menu_item_xfn', ''),
(124, 35, '_menu_item_url', ''),
(135, 37, '_menu_item_type', 'post_type'),
(136, 37, '_menu_item_menu_item_parent', '0'),
(137, 37, '_menu_item_object_id', '4'),
(138, 37, '_menu_item_object', 'page'),
(139, 37, '_menu_item_target', ''),
(140, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(141, 37, '_menu_item_xfn', ''),
(142, 37, '_menu_item_url', ''),
(143, 37, '_menu_item_orphaned', '1524943910') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(157, 48, '_edit_last', '1'),
(158, 48, '_edit_lock', '1526002294:1'),
(159, 48, 'cfs_fields', 'a:2:{i:0;a:8:{s:2:"id";i:1;s:4:"name";s:5:"price";s:5:"label";s:5:"price";s:4:"type";s:4:"text";s:5:"notes";s:43:"A numeric value of the price of the product";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:2:{s:13:"default_value";s:0:"";s:8:"required";s:1:"1";}}i:1;a:8:{s:2:"id";i:2;s:4:"name";s:0:"";s:5:"label";s:0:"";s:4:"type";s:4:"text";s:5:"notes";s:0:"";s:9:"parent_id";i:0;s:6:"weight";i:1;s:7:"options";a:2:{s:13:"default_value";s:0:"";s:8:"required";s:1:"0";}}}'),
(160, 48, 'cfs_rules', 'a:1:{s:10:"post_types";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:8:"products";}}}'),
(161, 48, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:6:"normal";s:11:"hide_editor";s:1:"0";}'),
(164, 49, '_edit_last', '1'),
(165, 49, '_edit_lock', '1527038062:1'),
(166, 50, '_edit_last', '1'),
(167, 50, '_edit_lock', '1527038047:1'),
(170, 51, '_edit_last', '1'),
(171, 51, '_edit_lock', '1527038021:1'),
(181, 55, '_customize_changeset_uuid', '029e99a8-2ad9-4d9b-ab42-1f33d7caf732'),
(183, 56, '_customize_changeset_uuid', '029e99a8-2ad9-4d9b-ab42-1f33d7caf732'),
(192, 63, '_wp_attached_file', '2018/05/about-hero.jpg'),
(193, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2667;s:4:"file";s:22:"2018/05/about-hero.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"about-hero-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"about-hero-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"about-hero-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"about-hero-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(194, 64, '_wp_attached_file', '2018/05/home-hero-1.jpg'),
(195, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2404;s:4:"file";s:23:"2018/05/home-hero-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"home-hero-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"home-hero-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"home-hero-1-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"home-hero-1-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(196, 55, '_edit_lock', '1526773955:1'),
(198, 65, '_wp_trash_meta_status', 'publish'),
(199, 65, '_wp_trash_meta_time', '1526953442'),
(200, 66, '_wp_trash_meta_status', 'publish'),
(201, 66, '_wp_trash_meta_time', '1526954845'),
(212, 69, '_edit_last', '1'),
(213, 69, '_edit_lock', '1527038032:1'),
(216, 70, '_edit_last', '1'),
(217, 70, '_edit_lock', '1527038008:1'),
(222, 71, '_edit_last', '1'),
(223, 71, '_edit_lock', '1527037997:1'),
(224, 72, '_edit_last', '1'),
(225, 72, '_edit_lock', '1527037984:1'),
(230, 73, '_edit_last', '1'),
(231, 73, '_edit_lock', '1527037972:1'),
(232, 74, '_edit_last', '1'),
(233, 74, '_edit_lock', '1527037952:1'),
(236, 75, '_edit_last', '1'),
(237, 75, '_edit_lock', '1527037938:1'),
(242, 76, '_edit_last', '1'),
(243, 76, '_edit_lock', '1527037926:1'),
(246, 77, '_edit_last', '1'),
(247, 77, '_edit_lock', '1527037917:1'),
(248, 78, '_edit_last', '1'),
(249, 78, '_edit_lock', '1527037898:1'),
(254, 79, '_edit_last', '1'),
(255, 79, '_edit_lock', '1527037886:1'),
(258, 80, '_edit_last', '1'),
(259, 80, '_edit_lock', '1527037860:1'),
(262, 81, '_edit_last', '1'),
(263, 81, '_edit_lock', '1528767994:1'),
(266, 82, '_wp_attached_file', '2018/05/gas-stove.jpg'),
(267, 82, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:21:"2018/05/gas-stove.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"gas-stove-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"gas-stove-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"gas-stove-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"gas-stove-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(268, 83, '_wp_attached_file', '2018/05/hand-knit-toque.jpg'),
(269, 83, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1845;s:4:"file";s:27:"2018/05/hand-knit-toque.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"hand-knit-toque-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"hand-knit-toque-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"hand-knit-toque-768x545.jpg";s:5:"width";i:768;s:6:"height";i:545;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"hand-knit-toque-1024x727.jpg";s:5:"width";i:1024;s:6:"height";i:727;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(270, 84, '_wp_attached_file', '2018/05/hiking-boots.jpg'),
(271, 84, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2376;s:6:"height";i:1782;s:4:"file";s:24:"2018/05/hiking-boots.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"hiking-boots-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"hiking-boots-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"hiking-boots-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"hiking-boots-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(272, 85, '_wp_attached_file', '2018/05/large-thermos.jpg'),
(273, 85, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:25:"2018/05/large-thermos.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"large-thermos-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"large-thermos-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"large-thermos-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"large-thermos-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(274, 86, '_wp_attached_file', '2018/05/leather-satchel.jpg'),
(275, 86, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:27:"2018/05/leather-satchel.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"leather-satchel-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"leather-satchel-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"leather-satchel-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"leather-satchel-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(276, 87, '_wp_attached_file', '2018/05/nylon-tents.jpg'),
(277, 87, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1732;s:4:"file";s:23:"2018/05/nylon-tents.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"nylon-tents-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"nylon-tents-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"nylon-tents-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"nylon-tents-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(278, 88, '_wp_attached_file', '2018/05/rustic-tools.jpg'),
(279, 88, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:2111;s:4:"file";s:24:"2018/05/rustic-tools.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"rustic-tools-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"rustic-tools-300x244.jpg";s:5:"width";i:300;s:6:"height";i:244;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"rustic-tools-768x624.jpg";s:5:"width";i:768;s:6:"height";i:624;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"rustic-tools-1024x831.jpg";s:5:"width";i:1024;s:6:"height";i:831;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(280, 89, '_wp_attached_file', '2018/05/stew-can.jpg'),
(281, 89, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:20:"2018/05/stew-can.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"stew-can-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"stew-can-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"stew-can-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"stew-can-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(282, 90, '_wp_attached_file', '2018/05/travel-hammock.jpg'),
(283, 90, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2288;s:6:"height";i:1520;s:4:"file";s:26:"2018/05/travel-hammock.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"travel-hammock-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"travel-hammock-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"travel-hammock-768x510.jpg";s:5:"width";i:768;s:6:"height";i:510;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"travel-hammock-1024x680.jpg";s:5:"width";i:1024;s:6:"height";i:680;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(284, 91, '_wp_attached_file', '2018/05/weathered-canoes.jpg'),
(285, 91, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:28:"2018/05/weathered-canoes.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"weathered-canoes-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"weathered-canoes-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"weathered-canoes-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"weathered-canoes-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(286, 92, '_wp_attached_file', '2018/05/wood-ax.jpg'),
(287, 92, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:19:"2018/05/wood-ax.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"wood-ax-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"wood-ax-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"wood-ax-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"wood-ax-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(288, 93, '_wp_attached_file', '2018/05/beach-tent.jpg'),
(289, 93, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:22:"2018/05/beach-tent.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"beach-tent-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"beach-tent-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"beach-tent-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"beach-tent-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(290, 94, '_wp_attached_file', '2018/05/camper-van.jpg'),
(291, 94, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1125;s:4:"file";s:22:"2018/05/camper-van.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"camper-van-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"camper-van-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"camper-van-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"camper-van-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(292, 95, '_wp_attached_file', '2018/05/ceramic-mugs.jpg'),
(293, 95, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:24:"2018/05/ceramic-mugs.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"ceramic-mugs-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"ceramic-mugs-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"ceramic-mugs-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"ceramic-mugs-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(294, 96, '_wp_attached_file', '2018/05/film-cameras.jpg'),
(295, 96, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:24:"2018/05/film-cameras.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"film-cameras-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"film-cameras-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"film-cameras-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"film-cameras-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(296, 97, '_wp_attached_file', '2018/05/flannel-shirt.jpg'),
(297, 97, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:25:"2018/05/flannel-shirt.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"flannel-shirt-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"flannel-shirt-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"flannel-shirt-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"flannel-shirt-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(300, 81, '_thumbnail_id', '92'),
(303, 80, '_thumbnail_id', '91'),
(306, 79, '_thumbnail_id', '90'),
(309, 78, '_thumbnail_id', '89'),
(312, 77, '_thumbnail_id', '88'),
(315, 76, '_thumbnail_id', '87'),
(318, 75, '_thumbnail_id', '86'),
(323, 74, '_thumbnail_id', '85'),
(326, 73, '_thumbnail_id', '84'),
(329, 72, '_thumbnail_id', '83'),
(332, 71, '_thumbnail_id', '82'),
(335, 70, '_thumbnail_id', '97'),
(338, 69, '_thumbnail_id', '96'),
(341, 51, '_thumbnail_id', '95'),
(344, 50, '_thumbnail_id', '94'),
(347, 49, '_thumbnail_id', '93'),
(348, 98, '_edit_last', '1'),
(349, 98, '_edit_lock', '1527031904:1'),
(350, 99, '_wp_attached_file', '2018/05/canoe-girl.jpg'),
(351, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:22:"2018/05/canoe-girl.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"canoe-girl-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"canoe-girl-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"canoe-girl-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"canoe-girl-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(352, 98, '_thumbnail_id', '99'),
(353, 100, '_edit_last', '1'),
(354, 100, '_edit_lock', '1527031939:1'),
(355, 101, '_wp_attached_file', '2018/05/beach-bonfire.jpg'),
(356, 101, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:25:"2018/05/beach-bonfire.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"beach-bonfire-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"beach-bonfire-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"beach-bonfire-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"beach-bonfire-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(357, 100, '_thumbnail_id', '101'),
(358, 102, '_edit_last', '1'),
(359, 102, '_edit_lock', '1527032058:1'),
(360, 103, '_wp_attached_file', '2018/05/mountain-hikers.jpg'),
(361, 103, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:27:"2018/05/mountain-hikers.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"mountain-hikers-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"mountain-hikers-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"mountain-hikers-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"mountain-hikers-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(362, 102, '_thumbnail_id', '103'),
(363, 104, '_edit_last', '1'),
(364, 104, '_edit_lock', '1527032089:1'),
(365, 105, '_wp_attached_file', '2018/05/night-sky.jpg'),
(366, 105, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:2000;s:4:"file";s:21:"2018/05/night-sky.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"night-sky-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"night-sky-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"night-sky-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"night-sky-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(367, 104, '_thumbnail_id', '105'),
(368, 8, '_wp_trash_meta_status', 'draft'),
(369, 8, '_wp_trash_meta_time', '1527032735'),
(370, 8, '_wp_desired_post_slug', ''),
(371, 56, '_edit_lock', '1529029514:1'),
(372, 56, '_edit_last', '1'),
(373, 108, '_menu_item_type', 'post_type'),
(374, 108, '_menu_item_menu_item_parent', '0'),
(375, 108, '_menu_item_object_id', '56'),
(376, 108, '_menu_item_object', 'page'),
(377, 108, '_menu_item_target', ''),
(378, 108, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(379, 108, '_menu_item_xfn', ''),
(380, 108, '_menu_item_url', ''),
(382, 109, '_menu_item_type', 'post_type_archive'),
(383, 109, '_menu_item_menu_item_parent', '0'),
(384, 109, '_menu_item_object_id', '-35'),
(385, 109, '_menu_item_object', 'products'),
(386, 109, '_menu_item_target', ''),
(387, 109, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(388, 109, '_menu_item_xfn', ''),
(389, 109, '_menu_item_url', ''),
(391, 108, '_wp_old_date', '2018-05-22'),
(392, 81, 'price', '$40.00'),
(393, 81, '', ''),
(394, 80, 'price', '$400.00'),
(395, 80, '', ''),
(396, 79, 'price', '$75.00'),
(397, 79, '', ''),
(398, 78, 'price', '$22.00'),
(399, 78, '', ''),
(400, 77, 'price', '$100.00'),
(401, 77, '', ''),
(402, 76, 'price', '$220.00'),
(403, 76, '', ''),
(404, 75, 'price', '$60.00'),
(405, 75, '', ''),
(406, 74, 'price', '$42.00'),
(407, 74, '', ''),
(408, 73, 'price', '$135.00'),
(409, 73, '', ''),
(410, 72, 'price', '$28.00'),
(411, 72, '', ''),
(412, 71, 'price', '$120.00'),
(413, 71, '', ''),
(414, 70, 'price', '$45.00'),
(415, 70, '', ''),
(416, 51, 'price', '$19.00'),
(417, 51, '', ''),
(418, 69, 'price', '$150.00'),
(419, 69, '', ''),
(420, 50, 'price', '$2500.00'),
(421, 50, '', ''),
(422, 49, 'price', '$155.00'),
(423, 49, '', ''),
(424, 110, '_wp_attached_file', '2016/04/van-camper.jpg'),
(425, 110, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1026;s:4:"file";s:22:"2016/04/van-camper.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"van-camper-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"van-camper-300x205.jpg";s:5:"width";i:300;s:6:"height";i:205;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"van-camper-768x525.jpg";s:5:"width";i:768;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"van-camper-1024x700.jpg";s:5:"width";i:1024;s:6:"height";i:700;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(426, 11, '_thumbnail_id', '110'),
(428, 111, '_wp_attached_file', '2016/04/warm-cocktail.jpg'),
(429, 111, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:25:"2016/04/warm-cocktail.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"warm-cocktail-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"warm-cocktail-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"warm-cocktail-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"warm-cocktail-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(430, 13, '_thumbnail_id', '111'),
(432, 112, '_wp_attached_file', '2016/03/healthy-camp-food.jpg'),
(433, 112, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:29:"2016/03/healthy-camp-food.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"healthy-camp-food-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"healthy-camp-food-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"healthy-camp-food-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"healthy-camp-food-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(434, 15, '_thumbnail_id', '112'),
(436, 113, '_wp_attached_file', '2016/03/solo-camping.jpg'),
(437, 113, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2515;s:6:"height";i:1830;s:4:"file";s:24:"2016/03/solo-camping.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"solo-camping-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"solo-camping-300x218.jpg";s:5:"width";i:300;s:6:"height";i:218;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"solo-camping-768x559.jpg";s:5:"width";i:768;s:6:"height";i:559;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"solo-camping-1024x745.jpg";s:5:"width";i:1024;s:6:"height";i:745;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(438, 17, '_thumbnail_id', '113'),
(440, 114, '_wp_attached_file', '2016/03/glamping.jpg'),
(441, 114, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:20:"2016/03/glamping.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"glamping-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"glamping-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"glamping-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"glamping-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(442, 19, '_thumbnail_id', '114'),
(443, 122, '_edit_lock', '1528957592:1'),
(444, 122, '_edit_last', '1'),
(445, 122, 'cfs_fields', 'a:1:{i:0;a:8:{s:2:"id";s:1:"3";s:4:"name";s:10:"hero_image";s:5:"label";s:10:"Hero-Image";s:4:"type";s:4:"file";s:5:"notes";s:22:"This is the Hero Image";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:3:{s:9:"file_type";s:5:"image";s:12:"return_value";s:3:"url";s:8:"required";s:1:"1";}}}'),
(446, 122, 'cfs_rules', 'a:1:{s:14:"page_templates";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:14:"page-about.php";}}}'),
(447, 122, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:6:"normal";s:11:"hide_editor";s:1:"0";}'),
(450, 4, '_wp_page_template', 'page-about.php'),
(454, 4, 'hero_image', '101') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(4, 1, '2018-04-27 03:14:59', '2018-04-27 03:14:59', '<h2>Our Story</h2>\r\nInhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.\r\n\r\nWe want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it every day.\r\n<h2>Our Team</h2>\r\nInhabitent Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.\r\n\r\nOur shop is nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-06-14 03:29:48', '2018-06-14 03:29:48', '', 0, 'http://localhost/student/?page_id=4', 0, 'page', '', 0),
(5, 1, '2018-04-27 02:55:55', '2018-04-27 02:55:55', '<h2>Our Story</h2>\r\nInhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.\r\n\r\nWe want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it every day.\r\n<h2>Our Team</h2>\r\nInhabitent Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.\r\n\r\nOur shop is nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!', 'About', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2018-04-27 02:55:55', '2018-04-27 02:55:55', '', 4, 'http://localhost/student/2018/04/27/4-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2018-04-27 03:15:25', '2018-04-27 03:15:25', '<h2>Physical Store</h2>\r\n<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.683120375551!2d-123.14035688448853!3d49.2634517800543!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC!5e0!3m2!1sen!2sca!4v1527056535328" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>\r\n\r\n<h2>We take camping supplies very seriously.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we\'ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>Send us mail!</h2>\r\n\r\n[wpforms id="119" title="false" description="false"]', 'Find us', '', 'publish', 'closed', 'closed', '', 'find-us', '', '', '2018-05-23 23:34:12', '2018-05-23 23:34:12', '', 0, 'http://localhost/student/?page_id=6', 0, 'page', '', 0),
(7, 1, '2018-04-27 02:58:37', '2018-04-27 02:58:37', '<h2>We take camping supplies very seriously.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we\'ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>Send us mail!</h2>\r\n[contact form goes here…]', 'Contact', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-04-27 02:58:37', '2018-04-27 02:58:37', '', 6, 'http://localhost/student/2018/04/27/6-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2018-05-22 23:45:35', '2018-05-22 23:45:35', '<h2>Getting Back to Nature in a Canoe</h2>\r\nSemiotics flannel artisan, squid whatever YOLO cold-pressed thundercats slow-carb normcore. Meggings lo-fi franzen waistcoat tattooed, pour-over etsy artisan. Seitan butcher tacos gentrify. Raw denim fap yr shabby chic. Thundercats mustache mlkshk messenger bag. Cronut crucifix wolf, artisan VHS skateboard chambray single-origin coffee fap. Shabby chic brooklyn meh kale chips, pour-over forage farm-to-table irony flannel mumblecore heirloom pickled cred.\r\n\r\nSwag chillwave chicharrones quinoa. Plaid yr small batch four loko. Polaroid scenester tat-tooed, biodiesel quinoa mumblecore 3 wolf moon leggings iPhone small batch sartorial medi-tation pop-up cardigan. Chillwave kitsch asymmetrical artisan, actually kogi cronut portland pork belly cardigan sustainable. Letterpress hammock heirloom kogi selvage biodiesel. Scenester occupy cornhole, banh mi post-ironic taxidermy crucifix mumblecore. Authentic pug next level, health goth slow-carb truffaut neutra literally biodiesel butcher retro.\r\n\r\nIntelligentsia food truck taxidermy before they sold out hoodie mustache. Disrupt trust fund gluten-free, tilde you probably haven\'t heard of them whatever seitan hammock listicle tumblr. Venmo kale chips kitsch authentic raw denim pabst. Quinoa chicharrones flannel PBR&amp;amp;B, narwhal sartorial jean shorts VHS DIY bespoke gastropub hella. Man braid squid humblebrag migas leggings, semiotics hella selvage kombucha blog williamsburg synth before they sold out. Plaid synth chicharrones, before they sold out neutra single-origin coffee cred. Pitchfork small batch etsy readymade, post-ironic pug viral.\r\n<h2>A Night with Friends at the Beach</h2>\r\nStreet art VHS tattooed iPhone humblebrag. Listicle literally crucifix, meditation hoodie cold-pressed street art brooklyn four dollar toast swag. Lumbersexual tacos kinfolk, sriracha normcore meggings stumptown williamsburg neutra lo-fi 8-bit. Authentic microdosing try-hard pug brunch knausgaard. IPhone narwhal pour-over, tote bag man bun typewriter aesthetic sartorial pug mumblecore. Polaroid lo-fi hoodie, wayfarers chillwave quinoa cliche echo park +1 brooklyn etsy paleo gentrify salvia. Pitchfork 90\'s hammock, 3 wolf moon bicycle rights chia slow-carb forage kombucha chicharrones.\r\n\r\nFranzen affogato next level artisan gluten-free bespoke. Brooklyn twee occupy, vinyl yr roof party jean shorts irony cray hella. Bushwick tilde pabst pour-over, semiotics poutine etsy tou-sled chambray. Slow-carb echo park jean shorts seitan. Salvia aesthetic gentrify man braid, messenger bag mixtape offal biodiesel chartreuse neutra. Williamsburg organic kickstarter pop-up literally. VHS lumbersexual migas roof party disrupt sartorial austin skateboard ethical.\r\n\r\nFixie bushwick tacos gastropub. Cliche neutra man bun vinyl authentic. Tote bag keytar synth knausgaard, asymmetrical flannel bushwick tacos dreamcatcher bitters small batch cronut go-dard hammock you probably haven\'t heard of them. Swag meditation ramps crucifix chia mes-senger bag, tattooed schlitz banjo selfies farm-to-table mixtape. Direct trade fingerstache way-farers franzen, godard intelligentsia bitters tacos chillwave etsy twee pabst plaid knausgaard single-origin coffee. Portland pug flexitarian, umami kale chips helvetica mustache taxidermy gluten-free disrupt fanny pack keffiyeh. Jean shorts pabst kinfolk, whatever vice wolf squid gastropub blog franzen swag.\r\n<h2>Taking in the View at Big Mountain</h2>\r\nMan braid occupy crucifix shoreditch gluten-free skateboard. Artisan pour-over green juice swag cred before they sold out, cliche occupy keytar ennui aesthetic YOLO. Deep v chicharrones farm-to-table jean shorts. Pug raw denim portland schlitz, fanny pack church-key beard trust fund fashion axe pork belly tumblr waistcoat chillwave vinyl lo-fi. Gentrify direct trade post-ironic, tote bag biodiesel bushwick vegan synth readymade wolf cray aesthetic. Ta-cos farm-to-table next level occupy kitsch squid. Meggings brunch migas blog selvage yuccie farm-to-table.\r\n\r\nBanjo crucifix lomo mixtape vice. Hoodie kogi lumbersexual, williamsburg cred jean shorts pork belly trust fund scenester disrupt ramps kickstarter 3 wolf moon readymade food truck. Chia thundercats bespoke mustache, meggings flannel ugh slow-carb artisan. Cronut put a bird on it pickled semiotics yuccie. Occupy echo park fanny pack humblebrag. Fingerstache semiotics artisan food truck blue bottle. Gentrify drinking vinegar tilde, sustainable marfa chill-wave hashtag direct trade distillery pinterest +1 wolf selfies.\r\n\r\nCardigan cronut fingerstache chartreuse hoodie everyday carry, pour-over kickstarter ethical try-hard stumptown truffaut kombucha whatever. 90\'s bitters swag, intelligentsia XOXO affoga-to mlkshk everyday carry asymmetrical forage schlitz sustainable 8-bit lo-fi. Kogi tofu ready-made, before they sold out put a bird on it banjo bitters master cleanse tumblr beard. Tousled etsy viral, retro stumptown squid iPhone poutine venmo. Retro narwhal gastropub banjo cold-pressed bitters, bespoke aesthetic single-origin coffee four loko cray. Man braid vinyl bio-diesel, cliche DIY bitters hashtag austin polaroid portland intelligentsia kogi affogato photo booth. Pinterest cronut gastropub kogi knausgaard portland.\r\n<h2>Star-Gazing at the Night Sky</h2>\r\nTote bag pitchfork food truck kickstarter quinoa sustainable. Literally +1 normcore bitters sel-vage, meditation bicycle rights jean shorts fap crucifix put a bird on it. Art party chillwave craft beer, distillery PBR&amp;B hoodie salvia bespoke keytar. Meditation chicharrones chartreuse meggings. Tattooed franzen narwhal tote bag. Raw denim chambray mlkshk tofu synth. Sarto-rial mlkshk four loko meggings, lumbersexual butcher vegan photo booth small batch vice pop-up salvia truffaut heirloom disrupt.\r\n\r\nYou probably haven\'t heard of them ethical migas pour-over. You probably haven\'t heard of them freegan hoodie butcher wayfarers truffaut. Artisan squid mustache thundercats +1. Asymmetrical selvage plaid butcher. Cronut small batch fashion axe blog VHS ennui. Vegan biodiesel four loko chambray, pickled marfa shoreditch sartorial chia stumptown mumblecore put a bird on it tacos. Keytar blue bottle tacos, stumptown skateboard pug sriracha ramps offal fap.\r\n\r\nStumptown lomo migas squid, ennui flexitarian normcore swag four dollar toast neutra authen-tic YOLO pour-over messenger bag organic. Chia distillery tofu sriracha lomo. Retro food truck hammock, pinterest next level everyday carry fanny pack meh typewriter pug bespoke tilde wayfarers williamsburg. Readymade flannel iPhone hella, brooklyn asymmetrical tacos actual-ly humblebrag tilde affogato four dollar toast post-ironic blue bottle. Fashion axe mumblecore cornhole scenester. Authentic tofu XOXO vegan literally. Yuccie single-origin coffee fixie food truck, hashtag cardigan poutine hoodie slow-carb fanny pack flexitarian.', 'Adventure Content', '', 'trash', 'closed', 'closed', '', '__trashed-3', '', '', '2018-05-22 23:45:35', '2018-05-22 23:45:35', '', 0, 'http://localhost/student/?page_id=8', 0, 'page', '', 0),
(9, 1, '2018-04-27 03:00:02', '2018-04-27 03:00:02', '<h2>Getting Back to Nature in a Canoe</h2>\r\nSemiotics flannel artisan, squid whatever YOLO cold-pressed thundercats slow-carb normcore. Meggings lo-fi franzen waistcoat tattooed, pour-over etsy artisan. Seitan butcher tacos gentrify. Raw denim fap yr shabby chic. Thundercats mustache mlkshk messenger bag. Cronut crucifix wolf, artisan VHS skateboard chambray single-origin coffee fap. Shabby chic brooklyn meh kale chips, pour-over forage farm-to-table irony flannel mumblecore heirloom pickled cred.\r\n\r\nSwag chillwave chicharrones quinoa. Plaid yr small batch four loko. Polaroid scenester tat-tooed, biodiesel quinoa mumblecore 3 wolf moon leggings iPhone small batch sartorial medi-tation pop-up cardigan. Chillwave kitsch asymmetrical artisan, actually kogi cronut portland pork belly cardigan sustainable. Letterpress hammock heirloom kogi selvage biodiesel. Scenester occupy cornhole, banh mi post-ironic taxidermy crucifix mumblecore. Authentic pug next level, health goth slow-carb truffaut neutra literally biodiesel butcher retro.\r\n\r\nIntelligentsia food truck taxidermy before they sold out hoodie mustache. Disrupt trust fund gluten-free, tilde you probably haven\'t heard of them whatever seitan hammock listicle tumblr. Venmo kale chips kitsch authentic raw denim pabst. Quinoa chicharrones flannel PBR&amp;amp;B, narwhal sartorial jean shorts VHS DIY bespoke gastropub hella. Man braid squid humblebrag migas leggings, semiotics hella selvage kombucha blog williamsburg synth before they sold out. Plaid synth chicharrones, before they sold out neutra single-origin coffee cred. Pitchfork small batch etsy readymade, post-ironic pug viral.\r\n<h2>A Night with Friends at the Beach</h2>\r\nStreet art VHS tattooed iPhone humblebrag. Listicle literally crucifix, meditation hoodie cold-pressed street art brooklyn four dollar toast swag. Lumbersexual tacos kinfolk, sriracha normcore meggings stumptown williamsburg neutra lo-fi 8-bit. Authentic microdosing try-hard pug brunch knausgaard. IPhone narwhal pour-over, tote bag man bun typewriter aesthetic sartorial pug mumblecore. Polaroid lo-fi hoodie, wayfarers chillwave quinoa cliche echo park +1 brooklyn etsy paleo gentrify salvia. Pitchfork 90\'s hammock, 3 wolf moon bicycle rights chia slow-carb forage kombucha chicharrones.\r\n\r\nFranzen affogato next level artisan gluten-free bespoke. Brooklyn twee occupy, vinyl yr roof party jean shorts irony cray hella. Bushwick tilde pabst pour-over, semiotics poutine etsy tou-sled chambray. Slow-carb echo park jean shorts seitan. Salvia aesthetic gentrify man braid, messenger bag mixtape offal biodiesel chartreuse neutra. Williamsburg organic kickstarter pop-up literally. VHS lumbersexual migas roof party disrupt sartorial austin skateboard ethical.\r\n\r\nFixie bushwick tacos gastropub. Cliche neutra man bun vinyl authentic. Tote bag keytar synth knausgaard, asymmetrical flannel bushwick tacos dreamcatcher bitters small batch cronut go-dard hammock you probably haven\'t heard of them. Swag meditation ramps crucifix chia mes-senger bag, tattooed schlitz banjo selfies farm-to-table mixtape. Direct trade fingerstache way-farers franzen, godard intelligentsia bitters tacos chillwave etsy twee pabst plaid knausgaard single-origin coffee. Portland pug flexitarian, umami kale chips helvetica mustache taxidermy gluten-free disrupt fanny pack keffiyeh. Jean shorts pabst kinfolk, whatever vice wolf squid gastropub blog franzen swag.\r\n<h2>Taking in the View at Big Mountain</h2>\r\nMan braid occupy crucifix shoreditch gluten-free skateboard. Artisan pour-over green juice swag cred before they sold out, cliche occupy keytar ennui aesthetic YOLO. Deep v chicharrones farm-to-table jean shorts. Pug raw denim portland schlitz, fanny pack church-key beard trust fund fashion axe pork belly tumblr waistcoat chillwave vinyl lo-fi. Gentrify direct trade post-ironic, tote bag biodiesel bushwick vegan synth readymade wolf cray aesthetic. Ta-cos farm-to-table next level occupy kitsch squid. Meggings brunch migas blog selvage yuccie farm-to-table.\r\n\r\nBanjo crucifix lomo mixtape vice. Hoodie kogi lumbersexual, williamsburg cred jean shorts pork belly trust fund scenester disrupt ramps kickstarter 3 wolf moon readymade food truck. Chia thundercats bespoke mustache, meggings flannel ugh slow-carb artisan. Cronut put a bird on it pickled semiotics yuccie. Occupy echo park fanny pack humblebrag. Fingerstache semiotics artisan food truck blue bottle. Gentrify drinking vinegar tilde, sustainable marfa chill-wave hashtag direct trade distillery pinterest +1 wolf selfies.\r\n\r\nCardigan cronut fingerstache chartreuse hoodie everyday carry, pour-over kickstarter ethical try-hard stumptown truffaut kombucha whatever. 90\'s bitters swag, intelligentsia XOXO affoga-to mlkshk everyday carry asymmetrical forage schlitz sustainable 8-bit lo-fi. Kogi tofu ready-made, before they sold out put a bird on it banjo bitters master cleanse tumblr beard. Tousled etsy viral, retro stumptown squid iPhone poutine venmo. Retro narwhal gastropub banjo cold-pressed bitters, bespoke aesthetic single-origin coffee four loko cray. Man braid vinyl bio-diesel, cliche DIY bitters hashtag austin polaroid portland intelligentsia kogi affogato photo booth. Pinterest cronut gastropub kogi knausgaard portland.\r\n<h2>Star-Gazing at the Night Sky</h2>\r\nTote bag pitchfork food truck kickstarter quinoa sustainable. Literally +1 normcore bitters sel-vage, meditation bicycle rights jean shorts fap crucifix put a bird on it. Art party chillwave craft beer, distillery PBR&amp;B hoodie salvia bespoke keytar. Meditation chicharrones chartreuse meggings. Tattooed franzen narwhal tote bag. Raw denim chambray mlkshk tofu synth. Sarto-rial mlkshk four loko meggings, lumbersexual butcher vegan photo booth small batch vice pop-up salvia truffaut heirloom disrupt.\r\n\r\nYou probably haven\'t heard of them ethical migas pour-over. You probably haven\'t heard of them freegan hoodie butcher wayfarers truffaut. Artisan squid mustache thundercats +1. Asymmetrical selvage plaid butcher. Cronut small batch fashion axe blog VHS ennui. Vegan biodiesel four loko chambray, pickled marfa shoreditch sartorial chia stumptown mumblecore put a bird on it tacos. Keytar blue bottle tacos, stumptown skateboard pug sriracha ramps offal fap.\r\n\r\nStumptown lomo migas squid, ennui flexitarian normcore swag four dollar toast neutra authen-tic YOLO pour-over messenger bag organic. Chia distillery tofu sriracha lomo. Retro food truck hammock, pinterest next level everyday carry fanny pack meh typewriter pug bespoke tilde wayfarers williamsburg. Readymade flannel iPhone hella, brooklyn asymmetrical tacos actual-ly humblebrag tilde affogato four dollar toast post-ironic blue bottle. Fashion axe mumblecore cornhole scenester. Authentic tofu XOXO vegan literally. Yuccie single-origin coffee fixie food truck, hashtag cardigan poutine hoodie slow-carb fanny pack flexitarian.', 'Adventure Content', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-04-27 03:00:02', '2018-04-27 03:00:02', '', 8, 'http://localhost/student/2018/04/27/8-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2016-04-14 03:02:36', '2016-04-14 03:02:36', 'Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.\r\n\r\nShabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out be-spoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.', 'Van Camping Photo Contest', '', 'publish', 'open', 'open', '', 'van-camping-photo-contest', '', '', '2018-05-23 03:13:12', '2018-05-23 03:13:12', '', 0, 'http://localhost/student/?p=11', 0, 'post', '', 0),
(12, 1, '2018-04-27 03:05:17', '2018-04-27 03:05:17', 'Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.\r\n\r\nShabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out be-spoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.', 'Van Camping Photo Contest', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2018-04-27 03:05:17', '2018-04-27 03:05:17', '', 11, 'http://localhost/student/2018/04/27/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2016-04-02 06:05:49', '2016-04-02 06:05:49', 'Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw den-im. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin cof-fee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sus-tainable asymmetrical williamsburg.\r\n\r\nHealth goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'publish', 'open', 'open', '', 'fireside-libations-3-warm-cocktail-recipes', '', '', '2018-05-23 03:13:37', '2018-05-23 03:13:37', '', 0, 'http://localhost/student/?p=13', 0, 'post', '', 0),
(14, 1, '2018-04-27 03:06:38', '2018-04-27 03:06:38', 'Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw den-im. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin cof-fee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland man bun scenester, wolf master cleanse iPhone selfies readymade godard sus-tainable asymmetrical williamsburg.\r\n\r\nHealth goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-04-27 03:06:38', '2018-04-27 03:06:38', '', 13, 'http://localhost/student/2018/04/27/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2016-03-31 05:34:43', '2016-03-31 05:34:43', 'Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skate-board cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leg-gings umami. Umami polaroid gentrify distillery tacos flannel green juice.\r\n\r\nTruffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund kef-fiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.', 'How To: Eating Healthy Meals in the Wild', '', 'publish', 'open', 'open', '', 'how-to-eating-healthy-meals-in-the-wild', '', '', '2018-05-23 03:13:59', '2018-05-23 03:13:59', '', 0, 'http://localhost/student/?p=15', 0, 'post', '', 0),
(16, 1, '2018-04-27 03:07:52', '2018-04-27 03:07:52', 'Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skate-board cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leg-gings umami. Umami polaroid gentrify distillery tacos flannel green juice.\r\n\r\nTruffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund kef-fiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.', 'How To: Eating Healthy Meals in the Wild', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2018-04-27 03:07:52', '2018-04-27 03:07:52', '', 15, 'http://localhost/student/2018/04/27/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2016-03-19 13:31:54', '2016-03-19 13:31:54', 'Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bi-cycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cli-che banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.\r\n\r\nVenmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.', '5 Tips for Solo Camping', '', 'publish', 'open', 'open', '', '5-tips-for-solo-camping', '', '', '2018-05-23 03:14:15', '2018-05-23 03:14:15', '', 0, 'http://localhost/student/?p=17', 0, 'post', '', 0),
(18, 1, '2018-04-27 03:08:47', '2018-04-27 03:08:47', 'Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bi-cycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cli-che banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.\r\n\r\nVenmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.', '5 Tips for Solo Camping', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2018-04-27 03:08:47', '2018-04-27 03:08:47', '', 17, 'http://localhost/student/2018/04/27/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2016-03-10 08:38:50', '2016-03-10 08:38:50', 'Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gas-tropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.\r\n\r\nKogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mum-blecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvet-ica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.\r\n\r\nViral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdos-ing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tat-tooed church-key biodiesel XOXO tumblr.', 'Glamping Made Easy', '', 'publish', 'open', 'open', '', 'glamping-made-easy', '', '', '2018-05-23 03:14:38', '2018-05-23 03:14:38', '', 0, 'http://localhost/student/?p=19', 0, 'post', '', 0),
(20, 1, '2018-04-27 03:09:44', '2018-04-27 03:09:44', 'Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gas-tropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.\r\n\r\nKogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mum-blecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvet-ica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.\r\n\r\nViral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdos-ing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tat-tooed church-key biodiesel XOXO tumblr.', 'Glamping Made Easy', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2018-04-27 03:09:44', '2018-04-27 03:09:44', '', 19, 'http://localhost/student/2018/04/27/19-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2018-04-28 19:14:20', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-28 19:14:20', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=22', 1, 'nav_menu_item', '', 0),
(23, 1, '2018-04-28 19:14:21', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-28 19:14:21', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=23', 1, 'nav_menu_item', '', 0),
(24, 1, '2018-04-28 19:14:21', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-28 19:14:21', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=24', 1, 'nav_menu_item', '', 0),
(26, 1, '2018-04-28 19:14:42', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-28 19:14:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=26', 1, 'nav_menu_item', '', 0),
(27, 1, '2018-04-28 19:14:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-28 19:14:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=27', 1, 'nav_menu_item', '', 0),
(28, 1, '2018-04-28 19:14:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-28 19:14:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=28', 1, 'nav_menu_item', '', 0),
(31, 1, '2018-04-28 19:25:03', '2018-04-28 19:25:03', '', 'inhabitent-logo-full-512x512', '', 'inherit', 'open', 'closed', '', 'inhabitent-logo-full-512x512', '', '', '2018-04-28 19:25:03', '2018-04-28 19:25:03', '', 0, 'http://localhost/student/wp-content/uploads/2018/04/inhabitent-logo-full-512x512.png', 0, 'attachment', 'image/png', 0),
(32, 1, '2018-04-28 19:25:30', '2018-04-28 19:25:30', 'http://localhost/student/wp-content/uploads/2018/04/cropped-inhabitent-logo-full-512x512.png', 'cropped-inhabitent-logo-full-512x512.png', '', 'inherit', 'open', 'closed', '', 'cropped-inhabitent-logo-full-512x512-png', '', '', '2018-04-28 19:25:30', '2018-04-28 19:25:30', '', 0, 'http://localhost/student/wp-content/uploads/2018/04/cropped-inhabitent-logo-full-512x512.png', 0, 'attachment', 'image/png', 0),
(34, 1, '2018-04-28 19:32:58', '2018-04-28 19:32:58', ' ', '', '', 'publish', 'closed', 'closed', '', '34', '', '', '2018-05-23 00:03:24', '2018-05-23 00:03:24', '', 0, 'http://localhost/student/?p=34', 3, 'nav_menu_item', '', 0),
(35, 1, '2018-04-28 19:32:58', '2018-04-28 19:32:58', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2018-05-23 00:03:24', '2018-05-23 00:03:24', '', 0, 'http://localhost/student/?p=35', 4, 'nav_menu_item', '', 0),
(37, 1, '2018-04-28 19:31:49', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-04-28 19:31:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=37', 1, 'nav_menu_item', '', 0),
(40, 1, '2018-04-28 19:35:29', '2018-04-28 19:35:29', '<h2>We take camping supplies very seriously.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we\'ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>Send us mail!</h2>\r\n[contact form goes here…]', 'Find us', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-04-28 19:35:29', '2018-04-28 19:35:29', '', 6, 'http://localhost/student/2018/04/28/6-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-04-28 19:35:57', '2018-04-28 19:35:57', '<h2>We take camping supplies very seriously.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we\'ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>Send us mail!</h2>\r\n[contact form goes here…]', 'Contact us', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-04-28 19:35:57', '2018-04-28 19:35:57', '', 6, 'http://localhost/student/2018/04/28/6-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2018-04-28 19:37:49', '2018-04-28 19:37:49', '<h2>Physical Store</h2>\r\n[map]\r\n<h2>We take camping supplies very seriously.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we\'ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>Send us mail!</h2>\r\n[contact form goes here…]', 'Contact us', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-04-28 19:37:49', '2018-04-28 19:37:49', '', 6, 'http://localhost/student/2018/04/28/6-revision-v1/', 0, 'revision', '', 0),
(44, 1, '2018-04-28 19:40:44', '2018-04-28 19:40:44', '<h2>Physical Store</h2>\r\n[map]\r\n<h2>We take camping supplies very seriously.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we\'ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>Send us mail!</h2>\r\n[contact form goes here…]', 'Find us', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-04-28 19:40:44', '2018-04-28 19:40:44', '', 6, 'http://localhost/student/2018/04/28/6-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2018-05-09 03:57:07', '2018-05-09 03:57:07', '', 'Product Fields', '', 'publish', 'closed', 'closed', '', 'product-fields', '', '', '2018-05-09 03:57:07', '2018-05-09 03:57:07', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=48', 0, 'cfs', '', 0),
(49, 1, '2018-05-11 01:34:36', '2018-05-11 01:34:36', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Beach Tent', '', 'publish', 'closed', 'closed', '', 'prod1', '', '', '2018-05-23 01:16:43', '2018-05-23 01:16:43', '', 0, 'http://localhost/student/?post_type=products&#038;p=49', 0, 'products', '', 0),
(50, 1, '2018-05-11 01:34:56', '2018-05-11 01:34:56', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Camper Van', '', 'publish', 'closed', 'closed', '', 'prod2', '', '', '2018-05-23 01:16:27', '2018-05-23 01:16:27', '', 0, 'http://localhost/student/?post_type=products&#038;p=50', 0, 'products', '', 0),
(51, 1, '2018-05-11 01:35:16', '2018-05-11 01:35:16', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Ceramic Mug', '', 'publish', 'closed', 'closed', '', 'prod3', '', '', '2018-05-23 01:16:04', '2018-05-23 01:16:04', '', 0, 'http://localhost/student/?post_type=products&#038;p=51', 0, 'products', '', 0),
(55, 1, '2018-05-11 03:03:43', '2018-05-11 03:03:43', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-05-11 03:03:43', '2018-05-11 03:03:43', '', 0, 'http://localhost/student/?page_id=55', 0, 'page', '', 0),
(56, 1, '2018-05-11 03:03:43', '2018-05-11 03:03:43', '', 'Jornal', '', 'publish', 'closed', 'closed', '', 'jornal', '', '', '2018-05-22 23:54:37', '2018-05-22 23:54:37', '', 0, 'http://localhost/student/?page_id=56', 0, 'page', '', 0),
(57, 1, '2018-05-11 03:03:43', '2018-05-11 03:03:43', '', 'Home', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2018-05-11 03:03:43', '2018-05-11 03:03:43', '', 55, 'http://localhost/student/2018/05/11/55-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2018-05-11 03:03:43', '2018-05-11 03:03:43', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2018-05-11 03:03:43', '2018-05-11 03:03:43', '', 56, 'http://localhost/student/2018/05/11/56-revision-v1/', 0, 'revision', '', 0),
(63, 1, '2018-05-19 23:53:06', '2018-05-19 23:53:06', '', 'about-hero', '', 'inherit', 'open', 'closed', '', 'about-hero', '', '', '2018-05-19 23:53:06', '2018-05-19 23:53:06', '', 4, 'http://localhost/student/wp-content/uploads/2018/05/about-hero.jpg', 0, 'attachment', 'image/jpeg', 0),
(64, 1, '2018-05-19 23:53:10', '2018-05-19 23:53:10', '', 'home-hero', '', 'inherit', 'open', 'closed', '', 'home-hero-2', '', '', '2018-05-19 23:53:10', '2018-05-19 23:53:10', '', 4, 'http://localhost/student/wp-content/uploads/2018/05/home-hero-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(65, 1, '2018-05-22 01:44:02', '2018-05-22 01:44:02', '{"old_sidebars_widgets_data":{"value":{"wp_inactive_widgets":[],"sidebar-1":["search-2","recent-posts-2","recent-comments-2","archives-2","categories-2","meta-2"]},"type":"global_variable","user_id":1,"date_modified_gmt":"2018-05-22 01:44:02"},"twentyseventeen::nav_menu_locations[top]":{"value":14,"type":"theme_mod","user_id":1,"date_modified_gmt":"2018-05-22 01:44:02"}}', '', '', 'trash', 'closed', 'closed', '', '3e2fdeec-b63b-4623-891e-cd6e0c91258b', '', '', '2018-05-22 01:44:02', '2018-05-22 01:44:02', '', 0, 'http://localhost/student/2018/05/22/3e2fdeec-b63b-4623-891e-cd6e0c91258b/', 0, 'customize_changeset', '', 0),
(66, 1, '2018-05-22 02:07:25', '2018-05-22 02:07:25', '{"old_sidebars_widgets_data":{"value":{"wp_inactive_widgets":[],"sidebar-1":["search-2","recent-posts-2","recent-comments-2","archives-2","categories-2","meta-2"]},"type":"global_variable","user_id":1,"date_modified_gmt":"2018-05-22 02:07:25"},"inhabitent::nav_menu_locations[primary]":{"value":14,"type":"theme_mod","user_id":1,"date_modified_gmt":"2018-05-22 02:07:25"}}', '', '', 'trash', 'closed', 'closed', '', '47616f77-bb91-41b4-ad4b-c12f66025452', '', '', '2018-05-22 02:07:25', '2018-05-22 02:07:25', '', 0, 'http://localhost/student/2018/05/22/47616f77-bb91-41b4-ad4b-c12f66025452/', 0, 'customize_changeset', '', 0),
(67, 1, '2018-05-22 03:35:14', '2018-05-22 03:35:14', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Camper Van', '', 'inherit', 'closed', 'closed', '', '50-autosave-v1', '', '', '2018-05-22 03:35:14', '2018-05-22 03:35:14', '', 50, 'http://localhost/student/2018/05/22/50-autosave-v1/', 0, 'revision', '', 0),
(69, 1, '2018-05-22 03:37:52', '2018-05-22 03:37:52', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Film Camera', '', 'publish', 'closed', 'closed', '', 'film-camera', '', '', '2018-05-23 01:16:14', '2018-05-23 01:16:14', '', 0, 'http://localhost/student/?post_type=products&#038;p=69', 0, 'products', '', 0),
(70, 1, '2018-05-22 03:38:29', '2018-05-22 03:38:29', '<p class="BodyA" style="line-height: 120%;">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Flannel Shirt', '', 'publish', 'closed', 'closed', '', 'flannel-shirt', '', '', '2018-05-23 01:15:50', '2018-05-23 01:15:50', '', 0, 'http://localhost/student/?post_type=products&#038;p=70', 0, 'products', '', 0),
(71, 1, '2018-05-22 03:39:07', '2018-05-22 03:39:07', '<p class="BodyA" style="line-height: 120%;">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Gas Stove', '', 'publish', 'closed', 'closed', '', 'gas-stove', '', '', '2018-05-23 01:15:39', '2018-05-23 01:15:39', '', 0, 'http://localhost/student/?post_type=products&#038;p=71', 0, 'products', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(72, 1, '2018-05-22 03:39:46', '2018-05-22 03:39:46', '<p class="BodyA" style="line-height: 120%;">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Hand-Knit Toque', '', 'publish', 'closed', 'closed', '', 'hand-knit-toque', '', '', '2018-05-23 01:15:25', '2018-05-23 01:15:25', '', 0, 'http://localhost/student/?post_type=products&#038;p=72', 0, 'products', '', 0),
(73, 1, '2018-05-22 03:40:29', '2018-05-22 03:40:29', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Hiking Boots', '', 'publish', 'closed', 'closed', '', 'hiking-boots', '', '', '2018-05-23 01:15:10', '2018-05-23 01:15:10', '', 0, 'http://localhost/student/?post_type=products&#038;p=73', 0, 'products', '', 0),
(74, 1, '2018-05-22 03:41:12', '2018-05-22 03:41:12', '<p class="BodyA" style="line-height: 120%;">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Large Thermos', '', 'publish', 'closed', 'closed', '', 'large-thermos', '', '', '2018-05-23 01:14:49', '2018-05-23 01:14:49', '', 0, 'http://localhost/student/?post_type=products&#038;p=74', 0, 'products', '', 0),
(75, 1, '2018-05-22 03:42:24', '2018-05-22 03:42:24', '<p class="BodyA" style="line-height: 120%;">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Leather Satchel', '', 'publish', 'closed', 'closed', '', 'leather-satchel', '', '', '2018-05-23 01:14:38', '2018-05-23 01:14:38', '', 0, 'http://localhost/student/?post_type=products&#038;p=75', 0, 'products', '', 0),
(76, 1, '2018-05-22 03:43:18', '2018-05-22 03:43:18', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Nylon Tents', '', 'publish', 'closed', 'closed', '', 'nylon-tents', '', '', '2018-05-23 01:14:28', '2018-05-23 01:14:28', '', 0, 'http://localhost/student/?post_type=products&#038;p=76', 0, 'products', '', 0),
(77, 1, '2018-05-22 03:44:16', '2018-05-22 03:44:16', '<p class="BodyA" style="line-height: 120%;">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Rustic Tools', '', 'publish', 'closed', 'closed', '', 'rustic-tools', '', '', '2018-05-23 01:14:10', '2018-05-23 01:14:10', '', 0, 'http://localhost/student/?post_type=products&#038;p=77', 0, 'products', '', 0),
(78, 1, '2018-05-22 03:45:13', '2018-05-22 03:45:13', 'Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.', 'Stew Can', '', 'publish', 'closed', 'closed', '', 'stew-can', '', '', '2018-05-23 01:14:01', '2018-05-23 01:14:01', '', 0, 'http://localhost/student/?post_type=products&#038;p=78', 0, 'products', '', 0),
(79, 1, '2018-05-22 03:45:44', '2018-05-22 03:45:44', '<p class="BodyA" style="line-height: 120%;">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Travel Hammock', '', 'publish', 'closed', 'closed', '', 'travel-hammock', '', '', '2018-05-23 01:13:48', '2018-05-23 01:13:48', '', 0, 'http://localhost/student/?post_type=products&#038;p=79', 0, 'products', '', 0),
(80, 1, '2018-05-22 03:46:14', '2018-05-22 03:46:14', '<p class="BodyA" style="line-height: 120%;">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Weathered Canoes', '', 'publish', 'closed', 'closed', '', 'weathered-canoes', '', '', '2018-05-23 01:13:14', '2018-05-23 01:13:14', '', 0, 'http://localhost/student/?post_type=products&#038;p=80', 0, 'products', '', 0),
(81, 1, '2018-05-22 03:48:39', '2018-05-22 03:48:39', '<p class="BodyA" style="line-height: 120%;">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Wood Ax', '', 'publish', 'closed', 'closed', '', 'wood-ax', '', '', '2018-05-23 01:13:01', '2018-05-23 01:13:01', '', 0, 'http://localhost/student/?post_type=products&#038;p=81', 0, 'products', '', 0),
(82, 1, '2018-05-22 03:59:11', '2018-05-22 03:59:11', '', 'gas-stove', '', 'inherit', 'open', 'closed', '', 'gas-stove-2', '', '', '2018-05-22 03:59:11', '2018-05-22 03:59:11', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/gas-stove.jpg', 0, 'attachment', 'image/jpeg', 0),
(83, 1, '2018-05-22 03:59:14', '2018-05-22 03:59:14', '', 'hand-knit-toque', '', 'inherit', 'open', 'closed', '', 'hand-knit-toque-2', '', '', '2018-05-22 03:59:14', '2018-05-22 03:59:14', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/hand-knit-toque.jpg', 0, 'attachment', 'image/jpeg', 0),
(84, 1, '2018-05-22 03:59:15', '2018-05-22 03:59:15', '', 'hiking-boots', '', 'inherit', 'open', 'closed', '', 'hiking-boots-2', '', '', '2018-05-22 03:59:15', '2018-05-22 03:59:15', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/hiking-boots.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 1, '2018-05-22 03:59:16', '2018-05-22 03:59:16', '', 'large-thermos', '', 'inherit', 'open', 'closed', '', 'large-thermos-2', '', '', '2018-05-22 03:59:16', '2018-05-22 03:59:16', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/large-thermos.jpg', 0, 'attachment', 'image/jpeg', 0),
(86, 1, '2018-05-22 03:59:17', '2018-05-22 03:59:17', '', 'leather-satchel', '', 'inherit', 'open', 'closed', '', 'leather-satchel-2', '', '', '2018-05-22 03:59:17', '2018-05-22 03:59:17', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/leather-satchel.jpg', 0, 'attachment', 'image/jpeg', 0),
(87, 1, '2018-05-22 03:59:17', '2018-05-22 03:59:17', '', 'nylon-tents', '', 'inherit', 'open', 'closed', '', 'nylon-tents-2', '', '', '2018-05-22 03:59:17', '2018-05-22 03:59:17', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/nylon-tents.jpg', 0, 'attachment', 'image/jpeg', 0),
(88, 1, '2018-05-22 03:59:18', '2018-05-22 03:59:18', '', 'rustic-tools', '', 'inherit', 'open', 'closed', '', 'rustic-tools-2', '', '', '2018-05-22 03:59:18', '2018-05-22 03:59:18', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/rustic-tools.jpg', 0, 'attachment', 'image/jpeg', 0),
(89, 1, '2018-05-22 03:59:19', '2018-05-22 03:59:19', '', 'stew-can', '', 'inherit', 'open', 'closed', '', 'stew-can-2', '', '', '2018-05-22 03:59:19', '2018-05-22 03:59:19', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/stew-can.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2018-05-22 03:59:20', '2018-05-22 03:59:20', '', 'travel-hammock', '', 'inherit', 'open', 'closed', '', 'travel-hammock-2', '', '', '2018-05-22 03:59:20', '2018-05-22 03:59:20', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/travel-hammock.jpg', 0, 'attachment', 'image/jpeg', 0),
(91, 1, '2018-05-22 03:59:20', '2018-05-22 03:59:20', '', 'weathered-canoes', '', 'inherit', 'open', 'closed', '', 'weathered-canoes-2', '', '', '2018-05-22 03:59:20', '2018-05-22 03:59:20', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/weathered-canoes.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2018-05-22 03:59:21', '2018-05-22 03:59:21', '', 'wood-ax', '', 'inherit', 'open', 'closed', '', 'wood-ax-2', '', '', '2018-05-22 03:59:21', '2018-05-22 03:59:21', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/wood-ax.jpg', 0, 'attachment', 'image/jpeg', 0),
(93, 1, '2018-05-22 03:59:22', '2018-05-22 03:59:22', '', 'beach-tent', '', 'inherit', 'open', 'closed', '', 'beach-tent', '', '', '2018-05-22 03:59:22', '2018-05-22 03:59:22', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/beach-tent.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2018-05-22 03:59:22', '2018-05-22 03:59:22', '', 'camper-van', '', 'inherit', 'open', 'closed', '', 'camper-van', '', '', '2018-05-22 03:59:22', '2018-05-22 03:59:22', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/camper-van.jpg', 0, 'attachment', 'image/jpeg', 0),
(95, 1, '2018-05-22 03:59:23', '2018-05-22 03:59:23', '', 'ceramic-mugs', '', 'inherit', 'open', 'closed', '', 'ceramic-mugs', '', '', '2018-05-22 03:59:23', '2018-05-22 03:59:23', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/ceramic-mugs.jpg', 0, 'attachment', 'image/jpeg', 0),
(96, 1, '2018-05-22 03:59:24', '2018-05-22 03:59:24', '', 'film-cameras', '', 'inherit', 'open', 'closed', '', 'film-cameras', '', '', '2018-05-22 03:59:24', '2018-05-22 03:59:24', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/film-cameras.jpg', 0, 'attachment', 'image/jpeg', 0),
(97, 1, '2018-05-22 03:59:24', '2018-05-22 03:59:24', '', 'flannel-shirt', '', 'inherit', 'open', 'closed', '', 'flannel-shirt-2', '', '', '2018-05-22 03:59:24', '2018-05-22 03:59:24', '', 0, 'http://localhost/student/wp-content/uploads/2018/05/flannel-shirt.jpg', 0, 'attachment', 'image/jpeg', 0),
(98, 1, '2018-05-22 23:34:05', '2018-05-22 23:34:05', '<p class="BodyA" style="line-height: 120%;">Semiotics flannel artisan, squid whatever YOLO cold-pressed thundercats slow-carb normcore. Meggings lo-fi franzen waistcoat tattooed, pour-over etsy artisan. Seitan butcher tacos gentrify. Raw denim fap yr shabby chic. Thundercats mustache mlkshk messenger bag. Cronut crucifix wolf, artisan VHS skateboard chambray single-origin coffee fap. Shabby chic brooklyn meh kale chips, pour-over forage farm-to-table irony flannel mumblecore heirloom pickled cred.</p>\r\n<p class="BodyA" style="line-height: 120%;"></p>\r\n<p class="BodyA" style="line-height: 120%;">Swag chillwave chicharrones quinoa. Plaid yr small batch four loko. Polaroid scenester tattooed, biodiesel quinoa mumblecore 3 wolf moon leggings iPhone small batch sartorial meditation pop-up cardigan. Chillwave kitsch asymmetrical artisan, actually kogi cronut portland pork belly cardigan sustainable. Letterpress hammock heirloom kogi selvage biodiesel. Scenester occupy cornhole, banh mi post-ironic taxidermy crucifix mumblecore. Authentic pug next level, health goth slow-carb truffaut neutra literally biodiesel butcher retro.</p>\r\n<p class="BodyA" style="line-height: 120%;"></p>\r\n<p class="BodyA" style="line-height: 120%;">Intelligentsia food truck taxidermy before they sold out hoodie mustache. Disrupt trust fund gluten-free, tilde you probably haven\'t heard of them whatever seitan hammock listicle tumblr. Venmo kale chips kitsch authentic raw denim pabst. Quinoa chicharrones flannel PBR&amp;amp;B, narwhal sartorial jean shorts VHS DIY bespoke gastropub hella. Man braid squid humblebrag migas leggings, semiotics hella selvage kombucha blog williamsburg synth before they sold out. Plaid synth chicharrones, before they sold out neutra single-origin coffee cred. Pitchfork small batch etsy readymade, post-ironic pug viral.</p>', 'Getting Back to Nature in a Canoe', '', 'publish', 'closed', 'closed', '', 'getting-back-to-nature-in-a-canoe', '', '', '2018-05-22 23:34:05', '2018-05-22 23:34:05', '', 0, 'http://localhost/student/?post_type=adventures&#038;p=98', 0, 'adventures', '', 0),
(99, 1, '2018-05-22 23:33:58', '2018-05-22 23:33:58', '', 'canoe-girl', '', 'inherit', 'open', 'closed', '', 'canoe-girl', '', '', '2018-05-22 23:33:58', '2018-05-22 23:33:58', '', 98, 'http://localhost/student/wp-content/uploads/2018/05/canoe-girl.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 1, '2018-05-22 23:34:41', '2018-05-22 23:34:41', 'Street art VHS tattooed iPhone humblebrag. Listicle literally crucifix, meditation hoodie cold-pressed street art brooklyn four dollar toast swag. Lumbersexual tacos kinfolk, sriracha normcore meggings stumptown williamsburg neutra lo-fi 8-bit. Authentic microdosing try-hard pug brunch knausgaard. IPhone narwhal pour-over, tote bag man bun typewriter aesthetic sartorial pug mumblecore. Polaroid lo-fi hoodie, wayfarers chillwave quinoa cliche echo park +1 brooklyn etsy paleo gentrify salvia. Pitchfork 90\'s hammock, 3 wolf moon bicycle rights chia slow-carb forage kombucha chicharrones.\r\n\r\n&nbsp;\r\n\r\nFranzen affogato next level artisan gluten-free bespoke. Brooklyn twee occupy, vinyl yr roof party jean shorts irony cray hella. Bushwick tilde pabst pour-over, semiotics poutine etsy tousled chambray. Slow-carb echo park jean shorts seitan. Salvia aesthetic gentrify man braid, messenger bag mixtape offal biodiesel chartreuse neutra. Williamsburg organic kickstarter pop-up literally. VHS lumbersexual migas roof party disrupt sartorial austin skateboard ethical.\r\n\r\n&nbsp;\r\n\r\nFixie bushwick tacos gastropub. Cliche neutra man bun vinyl authentic. Tote bag keytar synth knausgaard, asymmetrical flannel bushwick tacos dreamcatcher bitters small batch cronut godard hammock you probably haven\'t heard of them. Swag meditation ramps crucifix chia messenger bag, tattooed schlitz banjo selfies farm-to-table mixtape. Direct trade fingerstache wayfarers franzen, godard intelligentsia bitters tacos chillwave etsy twee pabst plaid knausgaard single-origin coffee. Portland pug flexitarian, umami kale chips helvetica mustache taxidermy gluten-free disrupt fanny pack keffiyeh. Jean shorts pabst kinfolk, whatever vice wolf squid gastropub blog franzen swag.', 'A Night with Friends at the Beach', '', 'publish', 'closed', 'closed', '', 'a-night-with-friends-at-the-beach', '', '', '2018-05-22 23:34:41', '2018-05-22 23:34:41', '', 0, 'http://localhost/student/?post_type=adventures&#038;p=100', 0, 'adventures', '', 0),
(101, 1, '2018-05-22 23:34:37', '2018-05-22 23:34:37', '', 'beach-bonfire', '', 'inherit', 'open', 'closed', '', 'beach-bonfire', '', '', '2018-05-22 23:34:37', '2018-05-22 23:34:37', '', 100, 'http://localhost/student/wp-content/uploads/2018/05/beach-bonfire.jpg', 0, 'attachment', 'image/jpeg', 0),
(102, 1, '2018-05-22 23:35:20', '2018-05-22 23:35:20', 'Man braid occupy crucifix shoreditch gluten-free skateboard. Artisan pour-over green juice swag cred before they sold out, cliche occupy keytar ennui aesthetic YOLO. Deep v chicharrones farm-to-table jean shorts. Pug raw denim portland schlitz, fanny pack church-key beard trust fund fashion axe pork belly tumblr waistcoat chillwave vinyl lo-fi. Gentrify direct trade post-ironic, tote bag biodiesel bushwick vegan synth readymade wolf cray aesthetic. Tacos farm-to-table next level occupy kitsch squid. Meggings brunch migas blog selvage yuccie farm-to-table.\r\n\r\nBanjo crucifix lomo mixtape vice. Hoodie kogi lumbersexual, williamsburg cred jean shorts pork belly trust fund scenester disrupt ramps kickstarter 3 wolf moon readymade food truck. Chia thundercats bespoke mustache, meggings flannel ugh slow-carb artisan. Cronut put a bird on it pickled semiotics yuccie. Occupy echo park fanny pack humblebrag. Fingerstache semiotics artisan food truck blue bottle. Gentrify drinking vinegar tilde, sustainable marfa chillwave hashtag direct trade distillery pinterest +1 wolf selfies.\r\n\r\nCardigan cronut fingerstache chartreuse hoodie everyday carry, pour-over kickstarter ethical try-hard stumptown truffaut kombucha whatever. 90\'s bitters swag, intelligentsia XOXO affogato mlkshk everyday carry asymmetrical forage schlitz sustainable 8-bit lo-fi. Kogi tofu readymade, before they sold out put a bird on it banjo bitters master cleanse tumblr beard. Tousled etsy viral, retro stumptown squid iPhone poutine venmo. Retro narwhal gastropub banjo cold-pressed bitters, bespoke aesthetic single-origin coffee four loko cray. Man braid vinyl biodiesel, cliche DIY bitters hashtag austin polaroid portland intelligentsia kogi affogato photo booth. Pinterest cronut gastropub kogi knausgaard portland.', 'Taking in the View at Big Mountain', '', 'publish', 'closed', 'closed', '', 'taking-in-the-view-at-big-mountain', '', '', '2018-05-22 23:36:39', '2018-05-22 23:36:39', '', 0, 'http://localhost/student/?post_type=adventures&#038;p=102', 0, 'adventures', '', 0),
(103, 1, '2018-05-22 23:35:07', '2018-05-22 23:35:07', '', 'mountain-hikers', '', 'inherit', 'open', 'closed', '', 'mountain-hikers', '', '', '2018-05-22 23:35:07', '2018-05-22 23:35:07', '', 102, 'http://localhost/student/wp-content/uploads/2018/05/mountain-hikers.jpg', 0, 'attachment', 'image/jpeg', 0),
(104, 1, '2018-05-22 23:37:10', '2018-05-22 23:37:10', '<p class="BodyA" style="line-height: 120%;">Tote bag pitchfork food truck kickstarter quinoa sustainable. Literally +1 normcore bitters selvage, meditation bicycle rights jean shorts fap crucifix put a bird on it. Art party chillwave craft beer, distillery PBR&amp;B hoodie salvia bespoke keytar. Meditation chicharrones chartreuse meggings. Tattooed franzen narwhal tote bag. Raw denim chambray mlkshk tofu synth. Sartorial mlkshk four loko meggings, lumbersexual butcher vegan photo booth small batch vice pop-up salvia truffaut heirloom disrupt.</p>\r\n<p class="BodyA" style="line-height: 120%;">You probably haven\'t heard of them ethical migas pour-over. You probably haven\'t heard of them freegan hoodie butcher wayfarers truffaut. Artisan squid mustache thundercats +1. Asymmetrical selvage plaid butcher. Cronut small batch fashion axe blog VHS ennui. Vegan biodiesel four loko chambray, pickled marfa shoreditch sartorial chia stumptown mumblecore put a bird on it tacos. Keytar blue bottle tacos, stumptown skateboard pug sriracha ramps offal fap.</p>\r\n<p class="BodyA" style="line-height: 120%;">Stumptown lomo migas squid, ennui flexitarian normcore swag four dollar toast neutra authentic YOLO pour-over messenger bag organic. Chia distillery tofu sriracha lomo. Retro food truck hammock, pinterest next level everyday carry fanny pack meh typewriter pug bespoke tilde wayfarers williamsburg. Readymade flannel iPhone hella, brooklyn asymmetrical tacos actually humblebrag tilde affogato four dollar toast post-ironic blue bottle. Fashion axe mumblecore cornhole scenester. Authentic tofu XOXO vegan literally. Yuccie single-origin coffee fixie food truck, hashtag cardigan poutine hoodie slow-carb fanny pack flexitarian.</p>', 'Star-Gazing at the Night Sky', '', 'publish', 'closed', 'closed', '', 'star-gazing-at-the-night-sky', '', '', '2018-05-22 23:37:10', '2018-05-22 23:37:10', '', 0, 'http://localhost/student/?post_type=adventures&#038;p=104', 0, 'adventures', '', 0),
(105, 1, '2018-05-22 23:37:06', '2018-05-22 23:37:06', '', 'night-sky', '', 'inherit', 'open', 'closed', '', 'night-sky', '', '', '2018-05-22 23:37:06', '2018-05-22 23:37:06', '', 104, 'http://localhost/student/wp-content/uploads/2018/05/night-sky.jpg', 0, 'attachment', 'image/jpeg', 0),
(106, 1, '2018-05-22 23:47:11', '2018-05-22 23:47:11', '', 'Jornal', '', 'inherit', 'closed', 'closed', '', '56-autosave-v1', '', '', '2018-05-22 23:47:11', '2018-05-22 23:47:11', '', 56, 'http://localhost/student/2018/05/22/56-autosave-v1/', 0, 'revision', '', 0),
(107, 1, '2018-05-22 23:54:37', '2018-05-22 23:54:37', '', 'Jornal', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2018-05-22 23:54:37', '2018-05-22 23:54:37', '', 56, 'http://localhost/student/2018/05/22/56-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2018-05-23 00:02:10', '2018-05-23 00:02:10', ' ', '', '', 'publish', 'closed', 'closed', '', '108', '', '', '2018-05-23 00:03:24', '2018-05-23 00:03:24', '', 0, 'http://localhost/student/?p=108', 2, 'nav_menu_item', '', 0),
(109, 1, '2018-05-23 00:02:10', '2018-05-23 00:02:10', 'Products', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2018-05-23 00:03:24', '2018-05-23 00:03:24', '', 0, 'http://localhost/student/?p=109', 1, 'nav_menu_item', '', 0),
(110, 1, '2018-05-23 03:13:04', '2018-05-23 03:13:04', '', 'van-camper', '', 'inherit', 'open', 'closed', '', 'van-camper', '', '', '2018-05-23 03:13:04', '2018-05-23 03:13:04', '', 11, 'http://localhost/student/wp-content/uploads/2016/04/van-camper.jpg', 0, 'attachment', 'image/jpeg', 0),
(111, 1, '2018-05-23 03:13:34', '2018-05-23 03:13:34', '', 'warm-cocktail', '', 'inherit', 'open', 'closed', '', 'warm-cocktail', '', '', '2018-05-23 03:13:34', '2018-05-23 03:13:34', '', 13, 'http://localhost/student/wp-content/uploads/2016/04/warm-cocktail.jpg', 0, 'attachment', 'image/jpeg', 0),
(112, 1, '2018-05-23 03:13:55', '2018-05-23 03:13:55', '', 'healthy-camp-food', '', 'inherit', 'open', 'closed', '', 'healthy-camp-food', '', '', '2018-05-23 03:13:55', '2018-05-23 03:13:55', '', 15, 'http://localhost/student/wp-content/uploads/2016/03/healthy-camp-food.jpg', 0, 'attachment', 'image/jpeg', 0),
(113, 1, '2018-05-23 03:14:11', '2018-05-23 03:14:11', '', 'solo-camping', '', 'inherit', 'open', 'closed', '', 'solo-camping', '', '', '2018-05-23 03:14:11', '2018-05-23 03:14:11', '', 17, 'http://localhost/student/wp-content/uploads/2016/03/solo-camping.jpg', 0, 'attachment', 'image/jpeg', 0),
(114, 1, '2018-05-23 03:14:29', '2018-05-23 03:14:29', '', 'glamping', '', 'inherit', 'open', 'closed', '', 'glamping', '', '', '2018-05-23 03:14:29', '2018-05-23 03:14:29', '', 19, 'http://localhost/student/wp-content/uploads/2016/03/glamping.jpg', 0, 'attachment', 'image/jpeg', 0),
(115, 1, '2018-05-23 06:27:17', '2018-05-23 06:27:17', '<h2>Physical Store</h2>\n<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.683120375551!2d-123.14035688448853!3d49.2634517800543!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC!5e0!3m2!1sen!2sca!4v1527056535328" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>\n\n<h2>We take camping supplies very seriously.</h2>\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we\'ve got your covered. Please contact us below with any questions comments or suggestions.\n<h2>Send us mail!</h2>\n[contact form goes here…]', 'Find us', '', 'inherit', 'closed', 'closed', '', '6-autosave-v1', '', '', '2018-05-23 06:27:17', '2018-05-23 06:27:17', '', 6, 'http://localhost/student/2018/05/23/6-autosave-v1/', 0, 'revision', '', 0),
(116, 1, '2018-05-23 06:27:24', '2018-05-23 06:27:24', '<h2>Physical Store</h2>\r\n<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.683120375551!2d-123.14035688448853!3d49.2634517800543!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC!5e0!3m2!1sen!2sca!4v1527056535328" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>\r\n\r\n<h2>We take camping supplies very seriously.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we\'ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>Send us mail!</h2>\r\n[contact form goes here…]', 'Find us', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-05-23 06:27:24', '2018-05-23 06:27:24', '', 6, 'http://localhost/student/2018/05/23/6-revision-v1/', 0, 'revision', '', 0),
(117, 1, '2018-05-23 17:56:52', '2018-05-23 17:56:52', '<h2>Physical Store</h2>\r\n<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.683120375551!2d-123.14035688448853!3d49.2634517800543!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC!5e0!3m2!1sen!2sca!4v1527056535328" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>\r\n\r\n<h2>We take camping supplies very seriously.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we\'ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>Send us mail!</h2>\r\n[contact form goes here…]', 'Find us', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-05-23 17:56:52', '2018-05-23 17:56:52', '', 6, 'http://localhost/student/2018/05/23/6-revision-v1/', 0, 'revision', '', 0),
(118, 1, '2018-05-23 23:31:32', '2018-05-23 23:31:32', '<p>This is the WPForms preview page. All your form previews will be handled on this page.</p><p>The page is set to private, so it is not publicly accessible. Please do not delete this page :) .</p>', 'WPForms Preview', '', 'private', 'closed', 'closed', '', 'wpforms-preview', '', '', '2018-05-23 23:31:32', '2018-05-23 23:31:32', '', 0, 'http://localhost/student/wpforms-preview/', 0, 'page', '', 0),
(119, 1, '2018-05-23 23:33:07', '2018-05-23 23:33:07', '{"id":"119","field_id":6,"fields":{"0":{"id":"0","type":"name","label":"Name","format":"simple","description":"","required":"1","size":"medium","simple_placeholder":"","simple_default":"","first_placeholder":"","first_default":"","middle_placeholder":"","middle_default":"","last_placeholder":"","last_default":"","css":""},"1":{"id":"1","type":"email","label":"Email","description":"","required":"1","size":"medium","placeholder":"","confirmation_placeholder":"","default_value":"","css":""},"3":{"id":"3","type":"text","label":"Subject","description":"","required":"1","size":"medium","placeholder":"","default_value":"","css":"","input_mask":""},"2":{"id":"2","type":"textarea","label":"Message","description":"","size":"medium","placeholder":"","css":""}},"settings":{"form_title":"Contact","form_desc":"","form_class":"","submit_text":"Submit","submit_text_processing":"Sending...","submit_class":"","honeypot":"1","notification_enable":"1","notifications":{"1":{"email":"{admin_email}","subject":"New Entry: Contact","sender_name":"{field_id=\\"0\\"}","sender_address":"{admin_email}","replyto":"{field_id=\\"1\\"}","message":"{all_fields}"}},"confirmation_type":"message","confirmation_message":"Thanks for contacting us! We will be in touch with you shortly.","confirmation_message_scroll":"1","confirmation_page":"4","confirmation_redirect":""},"meta":{"template":"contact"}}', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-05-23 23:36:22', '2018-05-23 23:36:22', '', 0, 'http://localhost/student/?post_type=wpforms&#038;p=119', 0, 'wpforms', '', 0),
(120, 1, '2018-05-23 23:34:12', '2018-05-23 23:34:12', '<h2>Physical Store</h2>\r\n<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.683120375551!2d-123.14035688448853!3d49.2634517800543!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC!5e0!3m2!1sen!2sca!4v1527056535328" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>\r\n\r\n<h2>We take camping supplies very seriously.</h2>\r\nInhabitent Camping Supply Co. knows what it takes to outfit a camping trip right. From flannel shirts to artisanal axes, we\'ve got your covered. Please contact us below with any questions comments or suggestions.\r\n<h2>Send us mail!</h2>\r\n\r\n[wpforms id="119" title="false" description="false"]', 'Find us', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-05-23 23:34:12', '2018-05-23 23:34:12', '', 6, 'http://localhost/student/6-revision-v1/', 0, 'revision', '', 0),
(122, 1, '2018-06-14 02:45:27', '2018-06-14 02:45:27', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-06-14 03:36:00', '2018-06-14 03:36:00', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=122', 0, 'cfs', '', 0),
(123, 1, '2018-06-16 23:14:39', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-06-16 23:14:39', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=123', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(11, 3, 0),
(11, 4, 0),
(13, 6, 0),
(13, 7, 0),
(13, 8, 0),
(15, 6, 0),
(15, 9, 0),
(15, 10, 0),
(17, 11, 0),
(17, 12, 0),
(19, 11, 0),
(19, 12, 0),
(19, 13, 0),
(34, 14, 0),
(35, 14, 0),
(49, 16, 0),
(49, 22, 0),
(50, 16, 0),
(50, 22, 0),
(51, 17, 0),
(51, 23, 0),
(69, 18, 0),
(69, 21, 0),
(70, 19, 0),
(70, 25, 0),
(71, 17, 0),
(71, 23, 0),
(72, 20, 0),
(72, 25, 0),
(73, 20, 0),
(73, 25, 0),
(74, 17, 0),
(74, 23, 0),
(75, 20, 0),
(75, 25, 0),
(76, 16, 0),
(76, 22, 0),
(77, 18, 0),
(77, 21, 0),
(78, 17, 0),
(78, 23, 0),
(79, 16, 0),
(79, 22, 0),
(80, 18, 0),
(80, 21, 0),
(81, 18, 0),
(81, 21, 0),
(108, 14, 0),
(109, 14, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'category', '', 0, 0),
(3, 3, 'category', '', 0, 1),
(4, 4, 'post_tag', '', 0, 1),
(6, 6, 'category', '', 0, 2),
(7, 7, 'post_tag', '', 0, 1),
(8, 8, 'post_tag', '', 0, 1),
(9, 9, 'post_tag', '', 0, 1),
(10, 10, 'post_tag', '', 0, 1),
(11, 11, 'category', '', 0, 2),
(12, 12, 'post_tag', '', 0, 2),
(13, 13, 'category', '', 0, 1),
(14, 14, 'nav_menu', '', 0, 4),
(16, 16, 'post_tag', '', 0, 4),
(17, 17, 'post_tag', '', 0, 4),
(18, 18, 'post_tag', '', 0, 4),
(19, 19, 'post_tag', '', 0, 1),
(20, 20, 'post_tag', '', 0, 3),
(21, 21, 'product_type', 'Get back to nature with all the tools and toys you need to enjoy the great outdoors.', 0, 4),
(22, 22, 'product_type', 'Get a good night\'s rest in the wild in a home away from home that travels well.', 0, 4),
(23, 23, 'product_type', 'Nothing beats food cooked over a fire. We have all you need for good camping eats.', 0, 4),
(25, 25, 'product_type', 'From flannel shirts to toques, look the part while roughing it in the great outdoors.', 0, 4) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Photography', 'photography', 0),
(3, 'Vans', 'vans', 0),
(4, 'Vans', 'vans', 0),
(6, 'Recipes', 'recipes', 0),
(7, 'Campfires', 'campfires', 0),
(8, 'Drinks', 'drinks', 0),
(9, 'Food', 'food', 0),
(10, 'Healthy', 'healthy', 0),
(11, 'How-tos', 'how-tos', 0),
(12, 'Tenting', 'tenting', 0),
(13, 'Not Really Camping', 'not-really-camping', 0),
(14, 'Main Menu', 'main-menu', 0),
(16, 'Sleep', 'sleep', 0),
(17, 'Eat', 'eat', 0),
(18, 'Do', 'do', 0),
(19, 'Where', 'where', 0),
(20, 'Wear', 'wear', 0),
(21, 'Do', 'do', 0),
(22, 'Sleep', 'sleep', 0),
(23, 'Eat', 'eat', 0),
(25, 'Wear', 'wear', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '123'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:38:"dashboard_right_now,dashboard_activity";s:4:"side";s:39:"dashboard_quick_press,dashboard_primary";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}'),
(21, 1, 'wp_user-settings', 'editor=html&libraryContent=browse&mfold=o'),
(22, 1, 'wp_user-settings-time', '1528947314'),
(23, 1, 'closedpostboxes_post', 'a:1:{i:0;s:16:"tagsdiv-post_tag";}'),
(24, 1, 'metaboxhidden_post', 'a:6:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}'),
(25, 1, '_wplv_settings', 'a:7:{s:4:"view";s:5:"group";s:4:"sort";s:6:"newest";s:5:"query";s:0:"";s:7:"legends";s:0:"";s:12:"fold_sidebar";i:1;s:17:"truncate_download";i:1;s:13:"custom_errors";s:0:"";}'),
(26, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(27, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(28, 1, 'nav_menu_recently_edited', '14'),
(29, 1, 'closedpostboxes_cfs', 'a:0:{}'),
(30, 1, 'metaboxhidden_cfs', 'a:1:{i:0;s:7:"slugdiv";}'),
(31, 1, 'meta-box-order_page', 'a:3:{s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:57:"postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(32, 1, 'screen_layout_page', '2'),
(33, 1, 'closedpostboxes_page', 'a:0:{}'),
(34, 1, 'metaboxhidden_page', 'a:5:{i:0;s:10:"postcustom";i:1;s:16:"commentstatusdiv";i:2;s:11:"commentsdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'),
(35, 1, 'session_tokens', 'a:2:{s:64:"d20cf3d75b0cfe6b1c043cc7d695bab2c264f4b3658c6fec82b195792d3f0220";a:4:{s:10:"expiration";i:1529198440;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36";s:5:"login";i:1529025640;}s:64:"e4425fcda983adbd23cc75cb8cb89a9547196162ee38e84a73d2e4a1502ca5ba";a:4:{s:10:"expiration";i:1529363677;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36";s:5:"login";i:1529190877;}}'),
(36, 2, 'nickname', 'instructor'),
(37, 2, 'first_name', 'Iris'),
(38, 2, 'last_name', ''),
(39, 2, 'description', ''),
(40, 2, 'rich_editing', 'true'),
(41, 2, 'syntax_highlighting', 'true'),
(42, 2, 'comment_shortcuts', 'false'),
(43, 2, 'admin_color', 'fresh'),
(44, 2, 'use_ssl', '0'),
(45, 2, 'show_admin_bar_front', 'true'),
(46, 2, 'locale', ''),
(47, 2, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'),
(48, 2, 'wp_user_level', '0'),
(49, 2, 'dismissed_wp_pointers', 'wp496_privacy'),
(50, 1, 'meta-box-order_products', 'a:3:{s:4:"side";s:38:"submitdiv,product_typediv,postimagediv";s:6:"normal";s:31:"cfs_input_48,postcustom,slugdiv";s:8:"advanced";s:0:"";}'),
(51, 1, 'screen_layout_products', '2') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BFl2hDxskYFPyB5/K0NSObQwNh2XdD0', 'admin', 'mail@server.com', '', '2018-04-25 03:17:46', '', 0, 'admin'),
(2, 'instructor', '$P$BsMrGsl1St8hVbn1qHPDPvFA2SQTVJ.', 'instructor', 'iris@redacademy.com', '', '2018-05-24 01:58:58', '1527127139:$P$BMh0J4ZJG2OS4lygcCV/t6GAsNtm251', 0, 'Iris') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

